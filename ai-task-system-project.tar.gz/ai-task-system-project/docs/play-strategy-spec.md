# AI任务系统 · 玩法策略规范

> **文档版本**：v1.0 | **最后更新**：2026-04-27
> **定位**：产品+技术团队的玩法策略设计规范，AI拆解引擎的执行蓝图

---

## 一、概念定义

### 1.1 玩法策略（Play Strategy）

一条玩法策略 = 一个完整的用户行为激励方案。

对标 marketing-se 的 Strategy（人群×时段×主题），Play Strategy 的坐标轴是 **行为×规则×奖励**：

| 概念 | marketing-se | AI任务系统 |
|------|-------------|-----------|
| 核心问题 | 给谁看什么 | 让谁做什么得什么 |
| 策略单元 | Strategy（投放方案） | Play Strategy（激励方案） |
| 拆解引擎 | Conversion Rules | Play Conversion Rules |
| 坐标轴 | 人群×时段×内容×供给×权益 | 行为×规则×奖励 |

### 1.2 转化规则（Play Conversion Rules）

运营需求（自然语言）→ 结构化玩法策略的 AI 拆解流程。四步完成：**类型识别 → 规则推断 → 奖励推断 → 完整性校验**。

### 1.3 维度注册表（Dimension Registry）

玩法策略的三根坐标轴：**行为维度**（做什么）、**规则维度**（怎么算完成）、**奖励维度**（得什么）。所有玩法策略都是这三根轴上的一个坐标点。

---

## 二、玩法策略规范（Play Strategy Spec）

每条玩法策略必须包含以下结构化字段：

```yaml
play_strategy:
  # ── 基础信息 ──
  play_name: string          # 玩法名称，如"五一签到7天领券"
  play_type: enum            # single_task | multi_task | two_layer
  campaign_type: enum        # 节日营销 | 用户召回 | 品类推广 | 日常促活 | 拉新裂变

  # ── 行为定义 ──
  task:
    action_type: enum        # signIn | order | pageView | invite | assist | share | subPlayComplete
    role: string             # 默认"user"；多角色场景填"inviter"/"invitee"等

  # ── 规则配置 ──
  rules:
    time_window: date_range  # "2026-05-01 ~ 2026-05-31"
    cycle_period: enum       # daily | weekly | monthly | total | custom
    threshold_ladder:        # 阶梯门槛数组
      - { level: 1, value: 3 }
      - { level: 2, value: 7 }
    continuity: enum         # cumulative(累计) | consecutive(连续) | interval(间隔)
    period_limit: number     # 每周期上限次数
    precondition:            # 前置条件
      type: enum             # none | check(校验型) | consume(消耗型)
      action: string         # 前置行为，如"pageView:detail_page"
    combo_logic: enum        # null | AND | OR（多任务组合逻辑）
    user_segment: string     # 人群包ID或标签，如"lapsed_30d"
    on_complete: enum        # direct_reward | report_event

  # ── 奖励配置 ──
  reward:
    tiers:
      - threshold: number
        reward_category: enum  # reward | package | lottery | rights
        reward_key: string     # 奖励资源ID，如"coupon_5off"
        distribution_limit: string  # "1/user/day"
        distribution_method: enum   # on_complete | on_return | manual_claim
        persona_group: array   # 画像分组，如["new_user", "high_value"]
        info_collect:          # 留资配置
          enabled: boolean
          fields: array        # ["phone", "address"]
```

### 字段约束速查

| 字段 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| play_name | ✅ | — | 唯一标识 |
| play_type | ✅ | single_task | 决定结构复杂度 |
| action_type | ✅ | — | 核心行为 |
| cycle_period | ✅ | total | 不填则整个活动周期算一次 |
| threshold_ladder | ✅ | [1] | 至少一档 |
| continuity | ❌ | cumulative | 签到类建议consecutive |
| precondition | ❌ | none | 有前置条件时必填 |
| combo_logic | ❌ | null | multi_task时必填 |
| persona_group | ❌ | [] | 不分组则统一奖励 |
| info_collect | ❌ | disabled | 留资场景必填 |

---

## 三、转化规则（Play Conversion Rules）

AI拆解运营需求的完整流程——四步走：

### 步骤0：玩法类型识别

从运营描述中提取信号词，判定玩法骨架：

| 信号词 | play_type | action_type | 典型场景 |
|--------|-----------|-------------|---------|
| 签到 / 每天 / 打卡 | single_task | signIn | 日常促活 |
| 下单 / 消费 / 购买 | single_task | order | 品类推广 |
| 邀请 / 拉人 / 砍价 | multi_task | invite + assist | 拉新裂变 |
| 先浏览再下单 / 前置条件 | single_task | order + precondition | 导流转化 |
| 每个节气 / 分期 / 子任务 | two_layer | subPlayComplete | 长线活动 |
| 分享 / 转发 | single_task | share | 传播扩散 |

> **决策树**：信号词匹配 → play_type确定 → action_type锁定 → 进入步骤1

### 步骤1：规则配置推断

```
运营描述 → 逐字段推断：

"连续签到7天"
  → cycle_period: daily
  → continuity: consecutive
  → threshold_ladder: [{level:1, value:7}]
  → period_limit: 1

"每月下单满3/5/10单"
  → cycle_period: monthly
  → continuity: cumulative
  → threshold_ladder: [{level:1,value:3},{level:2,value:5},{level:3,value:10}]
```

**推断优先级**：明确数字 > 隐含逻辑 > 行业惯例 > 默认值

### 步骤2：奖励结构推断

| 描述信号 | reward_category | distribution_method |
|----------|----------------|-------------------|
| 领券 / 优惠券 | reward | on_complete |
| 礼包 / 大礼包 | package | manual_claim |
| 抽奖 / 转盘 | lottery | on_complete |
| 会员权益 / 免费试用 | rights | on_complete |
| 返现 / 到账 | reward | on_return |

**画像分组推断**：出现"新客/老客""高价值/普通"等分群描述 → 启用 persona_group。

### 步骤3：完整性校验

```
校验清单：
[✓] play_name 非空
[✓] play_type 与 action_type 兼容（见维度注册表）
[✓] threshold_ladder 至少1档
[✓] multi_task 场景 combo_logic 非null
[✓] two_layer 场景子任务列表非空
[✓] reward.tiers 数量 ≥ threshold_ladder 档数
[✓] precondition.type 非none时 precondition.action 已填
[✓] time_window 起止日期合法
```

校验不通过 → 返回缺失字段列表，请运营补充。

---

## 四、维度注册表（Dimension Registry）

### 4.1 行为维度（Action Dimension）

| action_type | 含义 | 典型场景 | 兼容周期 | 兼容阶梯 | 支持前置条件 |
|-------------|------|---------|---------|---------|------------|
| signIn | 签到/打卡 | 日常促活 | daily | 单档/多档 | ❌ |
| order | 下单/消费 | 品类推广 | daily~total | 单档/多档/无限档 | ✅ |
| pageView | 浏览/访问 | 导流曝光 | daily~total | 单档 | ❌ |
| invite | 邀请好友 | 拉新裂变 | total | 多档 | ❌ |
| assist | 助力/砍价 | 社交裂变 | total | 单档 | ❌ |
| share | 分享/转发 | 传播扩散 | daily/total | 单档 | ❌ |
| check | 核销/验证 | 到店核销 | total | 单档 | ✅ |
| subPlayComplete | 子任务完成 | 长线活动 | custom | 多档 | ❌ |

### 4.2 规则维度（Rule Dimension）

**周期模式**

| cycle_period | 说明 | 适用场景 |
|-------------|------|---------|
| daily | 每天重置 | 签到、每日任务 |
| weekly | 每周重置 | 周度活跃 |
| monthly | 每月重置 | 月度消费 |
| total | 活动期不重置 | 累计行为 |
| custom | 自定义周期 | 节气、特殊日历 |

**阶梯模式**：单档（达标即发）/ 多档（3/5/10档递进）/ 无限档（每N次发一次，无上限）

**前置条件模式**：
- **无**（none）：直接执行主行为
- **校验型**（check）：验证前置行为已完成，不消耗（如"先浏览商品页"）
- **消耗型**（consume）：消耗前置资源（如"消耗积分解锁任务"）

**组合逻辑**：null（单任务）/ AND（全部完成才算）/ OR（完成任一即可）

### 4.3 奖励维度（Reward Dimension）

| reward_category | 说明 | distribution_method | 典型资源 |
|----------------|------|-------------------|---------|
| reward | 单一奖励 | on_complete / on_return | 优惠券、积分、红包 |
| package | 礼包组合 | manual_claim | 多券组合、新人礼包 |
| lottery | 抽奖机会 | on_complete | 转盘、刮刮卡 |
| rights | 权益开通 | on_complete | 会员试用、免运费 |

**画像分组**：无分组（统一奖励）/ 按人群分（新客vs老客不同奖励）/ 按行为分（高频vs低频差异化）

---

## 五、实战案例策略分析

### 案例1：签到7天领券

**运营需求**："用户连续签到7天，送满20减5优惠券"

**AI拆解路径**：

```
信号词"签到""每天" → single_task + signIn
"连续7天" → continuity: consecutive, threshold: 7, cycle_period: daily
"送优惠券" → reward_category: reward, method: on_complete
```

```yaml
play_type: single_task
action_type: signIn
cycle_period: daily
continuity: consecutive
threshold_ladder: [{level: 1, value: 7}]
reward: [{threshold: 7, category: reward, key: "coupon_20off5"}]
```

### 案例2：下单满N单阶梯奖励

**运营需求**："流失用户本月下单满3/5/10单，分别领10/30/100积分"

**AI拆解路径**：

```
"下单" → single_task + order
"本月""满3/5/10单" → cycle_period: monthly, cumulative, 3档阶梯
"流失用户" → user_segment: "lapsed_30d"
"积分" → reward_category: reward
```

```yaml
play_type: single_task
action_type: order
user_segment: "lapsed_30d"
cycle_period: monthly
continuity: cumulative
threshold_ladder: [{level:1,value:3},{level:2,value:5},{level:3,value:10}]
reward:
  - {threshold: 3, category: reward, key: "points_10"}
  - {threshold: 5, category: reward, key: "points_30"}
  - {threshold: 10, category: reward, key: "points_100"}
```

### 案例3：邀请好友砍价

**运营需求**："用户邀请3位好友助力砍价，邀请人得大额券，助力者得小额券"

**AI拆解路径**：

```
"邀请""助力" → multi_task + invite + assist
双角色 → inviter(阈值3) + invitee(阈值1)
combo_logic: AND
两种奖励 → 按角色分发
```

```yaml
play_type: multi_task
tasks:
  - {action_type: invite, role: inviter, threshold: 3}
  - {action_type: assist, role: invitee, threshold: 1}
combo_logic: AND
reward:
  - {role: inviter, category: reward, key: "coupon_50off20"}
  - {role: invitee, category: reward, key: "coupon_10off3"}
```

### 案例4：先浏览再下单双倍积分

**运营需求**："用户先浏览商品详情页，再下单可获双倍积分"

**AI拆解路径**：

```
"先浏览再下单" → single_task + order + precondition(check)
precondition.action: "pageView:detail_page"
"双倍积分" → reward_category: reward, key: "points_2x"
```

```yaml
play_type: single_task
action_type: order
precondition: {type: check, action: "pageView:detail_page"}
continuity: cumulative
reward: [{threshold: 1, category: reward, key: "points_2x"}]
```

### 案例5：中医节气签到

**运营需求**："做一个中医节气签到活动，每个节气是一期，用户下单满1单或浏览1次可以签到，累计完成3/5/9个节气签到解锁阶梯奖品，流失用户给更大的券，9次档大奖需要填写收货地址。"

**AI拆解路径**：

```
"每个节气""子任务" → two_layer + subPlayComplete
"下单或浏览" → 子任务层前置条件 precondition(consume) + combo: OR
"3/5/9个节气" → 大玩法层 threshold_ladder: [3, 5, 9]
"流失用户给更大的券" → persona_group: ["lapsed","new","default"]
"填写收货地址" → info_collect (仅9次档)
```

```yaml
# 大玩法层
play_type: two_layer
action_type: subPlayComplete
cycle_period: total          # 整季累计
threshold_ladder: [{level:1,value:3},{level:2,value:5},{level:3,value:9}]
reward:
  - {threshold: 3, category: package, key: "PKG_TCM_TIER3", persona_group: ["lapsed→8元券","new→5元券","default→5元券"]}
  - {threshold: 5, category: package, key: "PKG_TCM_TIER5", persona_group: ["lapsed→15元","new→10元","default→10元"]}
  - {threshold: 9, category: lottery, key: "LOTTERY_TCM_GRAND", info_collect: {enabled: true, fields: ["name","phone","address"]}}

# 子任务层（以谷雨为例）
sub_play:
  action_type: signIn
  cycle_period: custom       # 一个节气=一个周期
  precondition: {type: consume, action: "order|pageView", combo: OR}
  on_complete: report_event  # 完成→大玩法计数+1
```

### 案例维度速查

| 案例 | play_type | action | 周期 | 阶梯 | 前置条件 | 画像分组 | 留资 |
|------|-----------|--------|------|------|---------|---------|------|
| ①签到7天 | single_task | signIn | daily | 单档 | 无 | 无 | 无 |
| ②阶梯下单 | single_task | order | monthly | 3档 | 无 | 无 | 无 |
| ③邀请砍价 | multi_task | invite+assist | total | 单档 | 无 | 无 | 无 |
| ④浏览+下单 | single_task | order | total | 单档 | check | 无 | 无 |
| ⑤节气签到 | two_layer | subPlayComplete | custom | 3档(3/5/9) | consume+OR(子任务层) | 按人群(3+5档) | 地址(仅9档) |

---

## 六、与 marketing-se 策略引擎的对接模型

### 协作关系

```
marketing-se（投放策略）          AI任务系统（玩法策略）
┌─────────────────────┐       ┌──────────────────────┐
│ 决定：给谁看什么      │       │ 决定：让谁做什么得什么  │
│                     │       │                      │
│ 人群 × 时段 × 内容   │──────▶│ 行为 × 规则 × 奖励    │
│                     │  供给区 │                      │
│ 会场页面/资源位/坑位  │ 包含入口│ 签到按钮/任务卡片/进度条│
└─────────────────────┘       └──────────────────────┘
         │                              │
         └──────────┬───────────────────┘
                    ▼
            用户行为事件流（Kafka）
                    │
         ┌──────────┴──────────┐
         ▼                     ▼
   策略引擎更新画像       任务系统更新进度
```

### 连接点

1. **入口嵌入**：marketing-se 的供给区（会场坑位）包含任务中心入口组件
2. **事件共享**：用户行为事件通过 Kafka 双写，策略引擎和任务系统各自消费
3. **画像联动**：任务完成事件反馈给策略引擎，更新用户行为标签

### 数据流

```
用户点击签到按钮
  → 任务系统记录 signIn 事件
  → Kafka 发布 user.action.signIn
  → marketing-se 消费：更新用户活跃标签
  → 任务系统消费：检查进度 → 达标 → 发放奖励
  → 奖励发放事件 → Kafka → 策略引擎更新转化标签
```

---

## 七、Input/Output 定义

### 玩法策略引擎 Input

```json
{
  "campaign_description": "五一期间，流失用户连续签到7天送大额券，每天还能抽奖",
  "campaign_type": "节日营销",
  "target_users": "流失用户",
  "time_range": "2026-05-01 ~ 2026-05-07",
  "budget": "200000元",
  "available_rewards": ["coupon", "lottery"],
  "constraints": "每人每天最多签到1次"
}
```

### 玩法策略引擎 Output

```json
{
  "play_strategy": {
    "play_name": "五一回归签到领券",
    "play_type": "single_task",
    "campaign_type": "节日营销",
    "task": { "action_type": "signIn", "role": "user" },
    "rules": {
      "time_window": "2026-05-01 ~ 2026-05-07",
      "cycle_period": "daily",
      "threshold_ladder": [{"level": 1, "value": 7}],
      "continuity": "consecutive",
      "period_limit": 1,
      "user_segment": "lapsed_30d",
      "on_complete": "direct_reward"
    },
    "reward": {
      "tiers": [
        {"threshold": 7, "reward_category": "reward", "reward_key": "coupon_50off20", "distribution_method": "on_complete"},
        {"threshold": 1, "reward_category": "lottery", "reward_key": "daily_spin", "distribution_method": "on_complete"}
      ]
    }
  },
  "validation_result": {
    "status": "pass",
    "missing_fields": [],
    "warnings": ["budget未做精确校验，建议运营确认单用户成本"]
  },
  "recommended_atoms": ["T1-signIn", "R1-daily", "R3-consecutive", "W1-coupon", "W5-lottery"],
  "implementation_notes": "签到组件复用标准签到原子T1；每日抽奖独立触发，不与签到进度耦合"
}
```

---

> **总结**：玩法策略 = 行为 × 规则 × 奖励的结构化描述。AI拆解引擎通过四步转化规则，将运营的自然语言需求转化为可执行的策略 YAML。与 marketing-se 通过事件流和入口嵌入实现"投放×激励"的闭环协作。
