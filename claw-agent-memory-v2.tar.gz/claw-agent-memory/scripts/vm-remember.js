#!/usr/bin/env node

/**
 * vm-remember.js — 存储记忆并向量化（支持D1双写 + 多模型）
 *
 * 用法:
 *   node vm-remember.js <content> [选项]
 *
 * 选项:
 *   --key <tag>          语义标签（如 preference/css, decision/arch）
 *   --importance <0-1>   重要程度，默认 0.7
 *   --model <name>       嵌入模型：bge-small（默认）| bge-m3（中文优化，1024维）
 *   --appid <id>         AppId（优先于环境变量 FRIDAY_APP_ID）
 *   --metadata <json>    附加元数据（JSON 字符串）
 *   --no-d1              跳过 D1 云端写入（仅写本地）
 *
 * 示例:
 *   node vm-remember.js "用户偏好 TypeScript" --key preference/lang --importance 0.9
 *   node vm-remember.js "测试中文语义" --key test/bge-m3 --model bge-m3
 */

'use strict';

const fs    = require('fs');
const path  = require('path');
const https = require('https');
const HttpsProxyAgent = require('https-proxy-agent');
const crypto = require('crypto');

// ── 路径配置 ────────────────────────────────────────────────────────────────
const MEMORY_DIR  = path.join(process.env.HOME, '.openclaw', 'memory');
const CONFIG_PATH = path.join(MEMORY_DIR, 'config.json');

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    }
  } catch {}
  return {
    defaultModel: 'bge-m3',
    models: {
      'bge-small': { cfModel: '@cf/baai/bge-small-en-v1.5', dimensions: 384 },
      'bge-m3':    { cfModel: '@cf/baai/bge-m3',            dimensions: 1024 },
    },
    d1: {
      accountId:  '02098f6fe516b7886e79e03150a2ece4',
      databaseId: '44787f93-24e5-4f2b-9f74-c178e42dc102',
      token:      'cfut_GrSgTWTMF1hv4SBzd0V8MvdN8xHL8nv7H0RLB6By52e5a1ac',
    },
    proxy: 'http://127.0.0.1:8118',
  };
}

const CONFIG = loadConfig();
const CF_PROXY = process.env.HTTPS_PROXY || process.env.https_proxy || CONFIG.proxy || '';

function getDbPath(agentId) {
  if (agentId) return path.join(MEMORY_DIR, agentId, 'vectors.db');
  return path.join(MEMORY_DIR, 'vectors.db');
}

function resolveModel(alias) {
  const models = CONFIG.models || {};
  if (models[alias]) return models[alias].cfModel;
  if (alias.startsWith('@cf/') || alias.startsWith('@hf/')) return alias;
  return models['bge-small']?.cfModel || '@cf/baai/bge-small-en-v1.5';
}

// ── 参数解析 ────────────────────────────────────────────────────────────────
function parseArgs(argv) {
  const args = argv.slice(2);
  const result = {
    content:    null,
    key:        '',
    importance: 0.7,
    model:      CONFIG.defaultModel || 'bge-small',
    appid:      null,
    agent:      process.env.OPENCLAW_AGENT_ID || null,
    metadata:   {},
    noD1:       false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    if (arg.startsWith('--')) {
      const flag = arg.slice(2);
      const val  = args[i + 1];
      switch (flag) {
        case 'key':        result.key = val; i += 2; break;
        case 'importance': result.importance = parseFloat(val); i += 2; break;
        case 'model':      result.model = val; i += 2; break;
        case 'appid':      result.appid = val; i += 2; break;
        case 'agent':      result.agent = val; i += 2; break;
        case 'no-d1':      result.noD1 = true; i++; break;
        case 'metadata':
          try { result.metadata = JSON.parse(val); } catch {}
          i += 2;
          break;
        default: i++;
      }
    } else {
      if (!result.content) result.content = arg;
      i++;
    }
  }
  return result;
}

// ── CF Workers AI 嵌入 API ───────────────────────────────────────────────────
function embed(text, modelAlias) {
  return new Promise((resolve, reject) => {
    const cfModel = resolveModel(modelAlias);
    const url = `https://api.cloudflare.com/client/v4/accounts/${CONFIG.d1.accountId}/ai/run/${cfModel}`;
    const body = JSON.stringify({ text: [text] });
    const parsedUrl = new URL(url);

    const options = {
      hostname: parsedUrl.hostname,
      path:     parsedUrl.pathname,
      method:   'POST',
      headers: {
        'Authorization': `Bearer ${CONFIG.d1.token}`,
        'Content-Type':  'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
      ...(CF_PROXY ? { agent: new HttpsProxyAgent(CF_PROXY) } : {}),
    };

    const req = https.request(options, res => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json.error) {
            reject(new Error(`API 错误: ${json.error.message || JSON.stringify(json.error)}`));
          } else if (json.result && json.result.data && json.result.data[0]) {
            resolve({ vector: json.result.data[0], cfModel });
          } else {
            reject(new Error(`响应格式异常: ${data}`));
          }
        } catch (e) {
          reject(new Error(`JSON 解析失败: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── CF D1 API 调用 ────────────────────────────────────────────────────────────
function d1Query(sql, params) {
  params = params || [];
  return new Promise((resolve, reject) => {
    const { accountId, databaseId, token } = CONFIG.d1;
    const url = `https://api.cloudflare.com/client/v4/accounts/${accountId}/d1/database/${databaseId}/query`;
    const body = JSON.stringify({ sql, params });
    const parsedUrl = new URL(url);

    const options = {
      hostname: parsedUrl.hostname,
      path:     parsedUrl.pathname,
      method:   'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type':  'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
      ...(CF_PROXY ? { agent: new HttpsProxyAgent(CF_PROXY) } : {}),
    };

    const req = https.request(options, res => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (!json.success) {
            reject(new Error(`D1 错误: ${JSON.stringify(json.errors)}`));
          } else {
            resolve(json.result);
          }
        } catch (e) {
          reject(new Error(`D1 JSON 解析失败: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── 向量序列化 ────────────────────────────────────────────────────────────────
function vectorToBlob(vector) {
  const arr = new Float32Array(vector);
  return Buffer.from(arr.buffer);
}

// ── sql.js 数据库操作 ────────────────────────────────────────────────────────
async function loadDb(initSqlJs, dbPath) {
  if (!fs.existsSync(dbPath)) {
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const SQL = await initSqlJs();
    const db  = new SQL.Database();
    db.run(`CREATE TABLE IF NOT EXISTS memories (
      id TEXT PRIMARY KEY, content TEXT NOT NULL, embedding BLOB,
      key TEXT DEFAULT '', importance REAL DEFAULT 0.7,
      metadata TEXT DEFAULT '{}', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      model TEXT DEFAULT 'bge-small'
    )`);
    db.run('CREATE INDEX IF NOT EXISTS idx_key ON memories(key)');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    db.close();
  }
  const SQL      = await initSqlJs();
  const fileData = fs.readFileSync(dbPath);
  return new SQL.Database(fileData);
}

function saveDb(db, dbPath) {
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

// ── 写入 D1 ───────────────────────────────────────────────────────────────────
async function writeToD1(id, content, vector, key, importance, metadata, now, agentId, modelAlias) {
  const vectorJson = JSON.stringify(Array.from(vector));
  const nowTs = Math.floor(new Date(now).getTime() / 1000);
  const agent = agentId || 'global';

  // 检查是否已有相同 key
  if (key) {
    try {
      const existRes = await d1Query(
        'SELECT id FROM memories WHERE key = ? AND agent_id = ? LIMIT 1',
        [key, agent]
      );
      if (existRes && existRes[0] && existRes[0].results && existRes[0].results.length > 0) {
        const existId = existRes[0].results[0].id;
        await d1Query(
          'UPDATE memories SET content=?, vector=?, importance=?, metadata=?, updated_at=?, model=? WHERE id=?',
          [content, vectorJson, importance, JSON.stringify(metadata), nowTs, modelAlias, existId]
        );
        return { action: 'update', id: existId };
      }
    } catch (e) {
      // 查询失败时直接插入
    }
  }

  await d1Query(
    'INSERT INTO memories (id, key, content, vector, importance, created_at, updated_at, agent_id, metadata, model) VALUES (?,?,?,?,?,?,?,?,?,?)',
    [id, key, content, vectorJson, importance, nowTs, nowTs, agent, JSON.stringify(metadata), modelAlias]
  );
  return { action: 'insert', id };
}

// ── 主流程 ──────────────────────────────────────────────────────────────────
async function main() {
  const opts = parseArgs(process.argv);

  if (!opts.content) {
    console.error('用法: node vm-remember.js <content> [--key <tag>] [--importance <0-1>] [--model bge-small|bge-m3]');
    process.exit(1);
  }

  let initSqlJs;
  try {
    initSqlJs = require('sql.js');
  } catch {
    console.error('✗ 未找到 sql.js，请在技能目录运行: npm install');
    process.exit(1);
  }

  const dbPath = getDbPath(opts.agent);
  if (opts.agent) {
    process.stdout.write(`📦 使用 agent 专属库 [${opts.agent}]\n`);
  }

  // 向量化
  const cfModel = resolveModel(opts.model);
  process.stdout.write(`🔄 向量化内容（${opts.model} → ${cfModel}）...`);
  let vector;
  try {
    const result = await embed(opts.content, opts.model);
    vector = result.vector;
    console.log(` ✓ (${vector.length}维)`);
  } catch (e) {
    console.error(`\n✗ 嵌入 API 调用失败: ${e.message}`);
    process.exit(1);
  }

  // ── 写入本地 SQLite ────────────────────────────────────────────────────────
  const db  = await loadDb(initSqlJs, dbPath);
  const now = new Date().toISOString();
  const blob = vectorToBlob(vector);
  const metaStr = JSON.stringify(opts.metadata);

  let localId;
  let updated = false;

  if (opts.key) {
    const existing = db.exec(
      'SELECT id FROM memories WHERE key = ? LIMIT 1',
      [opts.key]
    );
    if (existing.length > 0 && existing[0].values.length > 0) {
      localId = existing[0].values[0][0];
      try { db.run('ALTER TABLE memories ADD COLUMN model TEXT DEFAULT \'bge-small\''); } catch {}
      db.run(
        'UPDATE memories SET content=?, embedding=?, importance=?, metadata=?, updated_at=?, model=? WHERE id=?',
        [opts.content, blob, opts.importance, metaStr, now, opts.model, localId]
      );
      updated = true;
      process.stdout.write(`✓ 本地更新 [${opts.key}] (id: ${localId})\n`);
    }
  }

  if (!updated) {
    localId = crypto.randomUUID();
    try { db.run('ALTER TABLE memories ADD COLUMN model TEXT DEFAULT \'bge-small\''); } catch {}
    db.run(
      'INSERT INTO memories (id, content, embedding, key, importance, metadata, created_at, updated_at, model) VALUES (?,?,?,?,?,?,?,?,?)',
      [localId, opts.content, blob, opts.key, opts.importance, metaStr, now, now, opts.model]
    );
    process.stdout.write(`✓ 本地写入 [${opts.key || '无标签'}] (id: ${localId})\n`);
  }

  saveDb(db, dbPath);
  db.close();

  // ── 写入 D1 云端 ──────────────────────────────────────────────────────────
  if (!opts.noD1) {
    process.stdout.write(`☁️  写入 D1 云端...`);
    try {
      const d1Result = await writeToD1(
        localId, opts.content, vector,
        opts.key, opts.importance, opts.metadata,
        now, opts.agent, opts.model
      );
      console.log(` ✓ (${d1Result.action}: ${d1Result.id})`);
    } catch (e) {
      console.log(` ⚠️  D1 写入失败（本地已保存）: ${e.message}`);
    }
  } else {
    console.log(`⏭️  跳过 D1（--no-d1）`);
  }

  console.log(`\n  内容: "${opts.content.substring(0, 80)}${opts.content.length > 80 ? '...' : ''}"`);
  console.log(`  模型: ${opts.model}（${vector.length}维）`);
  console.log(`  重要程度: ${opts.importance}`);
}

main().catch(err => {
  console.error('✗ 执行失败:', err.message);
  process.exit(1);
});
