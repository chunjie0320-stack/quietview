#!/bin/bash
# vm-warmup.sh - 会话热身脚本，自动召回相关记忆
# 用法: bash vm-warmup.sh "当前对话主题"

TOPIC="${1:-}"
VM_RECALL="node /root/.openclaw/skills/agent-memory/scripts/vm-recall.js"
SESSION_STATE="$HOME/.openclaw/memory/SESSION-STATE.md"
LIMIT="${2:-8}"

# ── 输出标题 ──────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  🔥 会话热身 / Session Warmup                        ║"
if [ -n "$TOPIC" ]; then
echo "║  主题: $TOPIC"
fi
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── 读取 SESSION-STATE.md（如存在）────────────────────────────────────
if [ -f "$SESSION_STATE" ]; then
    echo "📋 上次会话状态 (SESSION-STATE.md):"
    echo "──────────────────────────────────────────────────────"
    cat "$SESSION_STATE"
    echo "──────────────────────────────────────────────────────"
    echo ""
fi

# ── 召回相关记忆 ──────────────────────────────────────────────────────
if [ -z "$TOPIC" ]; then
    echo "⚠️  未提供主题，跳过记忆召回。"
    echo "   用法: bash vm-warmup.sh \"话题关键词\""
    exit 0
fi

echo "🧠 正在召回与「${TOPIC}」相关的记忆..."
echo ""

# 调用 vm-recall，设置合理的相似度阈值
RECALL_OUTPUT=$(HTTPS_PROXY=http://127.0.0.1:8118 $VM_RECALL "$TOPIC" \
    --limit "$LIMIT" \
    --threshold 0.25 2>&1)

RECALL_EXIT=$?

if [ $RECALL_EXIT -ne 0 ]; then
    echo "⚠️  记忆召回失败（可能是网络问题或数据库未初始化）"
    echo "   错误信息: $RECALL_OUTPUT"
    echo ""
    echo "   初始化命令: node /root/.openclaw/skills/agent-memory/scripts/vm-init.js"
    exit 1
fi

echo "$RECALL_OUTPUT"

# ── 输出使用提示 ──────────────────────────────────────────────────────
echo ""
echo "──────────────────────────────────────────────────────"
echo "💡 提示: 将以上记忆注入对话上下文，让喵子延续已有认知"
echo "   存储新记忆: node /root/.openclaw/skills/agent-memory/scripts/vm-remember.js \"内容\" --key \"xxx/yyy\""
echo "──────────────────────────────────────────────────────"
echo ""
