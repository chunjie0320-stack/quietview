# AI Native 任务系统（原名：任务中心）

> 用AI接管营销任务的"选人×选券×写文案×选时机"全链路，运营从填表员变成审稿人。

---

## 版本演进

| 版本 | 核心变化 |
|------|----------|
| **V3** | 基础Apple蓝白风 → 卡片式布局，被否（"花里胡哨"）— 未包含在本包 |
| **V4** | CRM企业后台风格确立，pill要素面板 + 填槽值回显 + 且/或逻辑连接器 + 原子可编辑表单 |
| **V5** | 三栏布局探索：左=AI Thinking推理链 / 中=画布dot grid+9节气SVG连线 / 右=节点配置 |
| **V6** | V4外框 + V5三栏替换Step2，奖励增删 + 画布子任务增删，两版融合 |
| **V7** | "底层对了表层错了"转折 — 回归信息密度，去掉装饰，Step2三栏精简，最终交付版 |

---

## 核心决策

1. **原子层对运营透明** — 不展示规则表达式，运营只看到可编辑表单控件（select/input/date），AI填值+运营可改
2. **"底层对了表层错了"** — V5/V6架构正确但表层花哨，V7回归企业后台信息密度，是关键转折
3. **女王大人B端设计偏好** — 信息密度和效率 > 视觉花哨；参考云微CRM/神策/GrowingIO；小圆角4px、无毛玻璃、紧凑间距
4. **MVP铁律** — ① 全流程B端→C端→数据回流完整跑通，中间不能断 ② 不阻塞上线的才能放2期

---

## 文件索引

```
ai-task-system-project/
├── README.md                         本文件
├── demo/
│   ├── ai-task-system-demo-v4.html   CRM风格确立版（65KB）
│   ├── ai-task-system-demo-v5.html   三栏画布探索版（16KB）
│   ├── ai-task-system-demo-v6.html   V4+V5融合版（64KB）
│   └── ai-task-system-demo-v7.html   最终交付版（55KB）
├── docs/
│   ├── task-center.md                任务形态字典 + 联动规则
│   ├── task-center-prd-v1.md         PRD v1（9章/499行/18.7KB）
│   ├── task-center-ui-spec.md        美团UI设计规范提炼（515行）
│   ├── play-strategy-spec.md         玩法策略规范（87处中文注释）
│   ├── task-atoms-doc.md             任务原子化知识库文档
│   ├── task-atoms.yaml               原子能力字典（体）
│   └── task-visual-rules.yaml        渲染规则（用）
├── diagrams/
│   ├── product-flow.drawio           产品流程泳道图
│   ├── user-journey.drawio           用户旅程图
│   └── whiteboard-20260408.jpg       4/8白板板书
├── m-demo/
│   └── task-center-m-demo.html       M端操作台Demo（3角色×3Flow）
├── screenshots/
│   ├── v7/                           V7 Demo截图（7张）
│   └── industry-cases/               行业案例截图（6张）
├── memory/
│   └── project-memory.md             项目专属记忆（从MEMORY.md提取）
└── reference/
    └── marketing-se-ref/             策略引擎×任务中心概念对照
```

---

## 相关Wiki链接

| 文档 | 链接 |
|------|------|
| PRD v1 | https://km.sankuai.com/collabpage/2759500322 |
| 玩法策略规范 | https://km.sankuai.com/collabpage/2759822135 |
| MRD（中医签到需求） | https://km.sankuai.com/collabpage/2707322068 |
| 千人千面 | https://km.sankuai.com/collabpage/2757355508 |
| 高达组件对接PRD | https://km.sankuai.com/collabpage/2758643144 |
| 玩法·任务·奖励原子设计 | https://km.sankuai.com/collabpage/2759413915 |

---

*打包时间：2026-04-27 22:12 CST*
