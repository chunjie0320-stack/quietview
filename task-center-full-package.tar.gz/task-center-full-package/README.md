# AI Native 任务中心 — 完整项目包

> **首发场景**：中医节气签到 | **MVP节点**：2026年5月24日（小满）

---

## 📁 目录结构

```
task-center-full-package/
├── docs/                        # 📄 核心文档
│   ├── task-center-prd-v1.md    # PRD正文（9章/499行/18.7KB）
│   ├── task-center.md           # 项目核心文档（B→C联动映射/任务形态字典/Mock画像）
│   ├── task-center-ui-spec.md   # C端UI规范
│   ├── task-atoms-doc.md        # 原子化能力文档（4类16个原子能力）
│   ├── task-atoms.yaml          # 原子能力YAML定义
│   ├── task-visual-rules.yaml   # 视觉规则YAML
│   └── material-digest.md       # 11份参考资料汇总摘要
│
├── drawio/                      # 🔀 流程图（draw.io可直接打开编辑）
│   ├── user-journey.drawio      # 用户旅程图（蓝/绿/橙三阶段+判断分支）
│   ├── user-journey-v0.drawio   # 用户旅程图 v0（早期版本）
│   ├── product-flow.drawio      # 产品流程图（运营/系统/用户 三层泳道）
│   └── product-flow-v0.drawio   # 产品流程图 v0（早期版本）
│
├── demo/                        # 🖥️ 交互Demo（浏览器直接打开）
│   ├── m-demo.html              # M端运营操作台（玩法列表/6步创建向导/三角色权限）
│   ├── m-demo-v0.html           # M端 v0 版本
│   ├── c-demo.html              # C端签到交互Demo
│   ├── native-demo.html         # AI Native完整Demo（AI对话→策略→监控→C端）
│   └── task_center_v3.html      # V3最终版（含千人千面三画像+运营工作台）
│
├── arch/                        # 🏗️ 架构图
│   ├── arch-diagram.html        # 三层架构交互图（HTML可视化）
│   └── task-center-arch.png     # 架构图截图
│
├── wiki/                        # 📝 学城Wiki原始内容
│   ├── prd-wiki.citadelmd       # Wiki原始格式（CitadelMD，97KB）
│   └── task-center-wiki.md      # Wiki Markdown导出
│
├── design-system/               # 🎨 设计系统
│   ├── SKILL.md                 # 设计Skill说明
│   ├── task-atoms-snapshot.yaml # 原子能力快照
│   ├── task-visual-rules-snapshot.yaml # 视觉规则快照
│   └── ui-spec-summary.md       # UI规范摘要
│
├── references/                  # 📎 参考组件
│   ├── sign-in-component.css    # 签到组件样式
│   └── sign-in-component.js     # 签到组件逻辑
│
├── screenshots/                 # 📸 截图
│   ├── v3-iphone-sign.png       # V3 iPhone签到效果
│   ├── v3-sign-closeup.png      # 签到组件特写
│   ├── v3-sign-fixed.png        # 签到修复后效果
│   └── v3-trio-sign-upgrade.png # 三画像并排对比
│
└── README.md                    # 本文件
```

## 🔗 关键链接

- **学城Wiki**：https://km.sankuai.com/collabpage/2759500322
- **千人千面方案**：https://km.sankuai.com/collabpage/2757355508
- **AI Native方案初版**：https://km.sankuai.com/collabpage/2756586746

## 🚀 快速开始

1. 读PRD → `docs/task-center-prd-v1.md`
2. 看Demo → 浏览器打开 `demo/task_center_v3.html`（最完整版）
3. 编辑流程图 → draw.io打开 `drawio/*.drawio`
4. 了解原子能力 → `docs/task-atoms-doc.md`
