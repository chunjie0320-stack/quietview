# 美团会员任务系统原子化梳理文档

> **来源**：会员任务系统2.0 KM文档（contentId: 1622416115）
>
> **核心文档**：
> - 营销活动-任务系统2.0总体设计（1967636441）
> - 任务2.0-产品化设计方案（1856338613）
> - 1.0任务类型与2.0事件配置梳理（1820113203）
> - 事件类型说明（2133220879）
> - 邀请助力任务流程说明（2281416411）
>
> **整理日期**：2026-04-13
>
> **整理原则**："浅通用" — 原子不变，组合规则用YAML配置，扩展新业务只加配置不改代码

---

## 目录

1. [系统架构概述](#1-系统架构概述)
2. [三层结构模型](#2-三层结构模型)
3. [任务类型完整列表（A类原子）](#3-任务类型完整列表)
4. [原子枚举表（B类）](#4-原子枚举表)
5. [YAML原子组合示例（C类）](#5-yaml原子组合示例)
6. [规则引擎详解](#6-规则引擎详解)
7. [循环能力详解](#7-循环能力详解)
8. [后置处理能力](#8-后置处理能力)
9. [C端交互模式](#9-c端交互模式)
10. [任务模板机制](#10-任务模板机制)

---

## 1. 系统架构概述

### 1.1 设计目标

任务系统2.0从1.0的"模板模式"（每种任务类型对应独立烟囱代码）升级为**事件驱动 + 规则引擎**架构，核心目标：

- **研发效率**：新接入任务类型只需配置，无代码或极少代码，提升50%+
- **功能覆盖**：核心功能覆盖1.0全部50+种任务类型
- **平台化**：通过用户事件模块+流程扩展点，支持不同业务诉求

### 1.2 事件分类

任务2.0基于**用户事件驱动**，事件按来源分三类：

| 事件类型 | 说明 | 特点 | 代表事件 |
|---------|------|------|---------|
| 前端上报型 | 前端主动调接口上报 | 可实时感知；可控制准入；需携带subTaskId（浏览/分享/订阅） | 签到、浏览、分享、订阅提醒、邀请、助力 |
| 消息触发型 | 后端实时感知行为流 | 可实时感知；系统自动处理；达成规则需配ts>领取时间 | 全景下单 |
| 查询型 | 用户进入页面时查询下游接口 | 不能实时感知；用户进页面触发；达成规则需配ts>领取时间 | 投票 |

---

## 2. 三层结构模型

```
任务包（TaskActivity）
  └── 任务（Task）              ← 用户可见可领取的最小单元
        ├── 领取规则             ← 规则引擎配置（人群/画像等准入条件）
        ├── 循环方式             ← 不循环/按时间/连续/累计
        ├── 事件配置（eventConfigs）← 各事件类型的特有参数
        └── 子任务（SubTask）[] ← 行为达成和发奖的最小单元
              ├── 达成规则        ← 规则引擎配置（事件规则+聚合条件）
              ├── 后置动作        ← 发奖/发Push/领取其他任务
              └── 发奖配置        ← prizeType/prizeKey/prizeMomentType
```

**关键概念**：

- **任务包**：承载一个营销活动下所有任务
- **任务**：用户视角最小可见单元，1个任务可绑定多个事件类型（任务模板的核心）
- **子任务**：进度里程碑单元，每个子任务独立配置达成规则和奖励

---

## 3. 任务类型完整列表

### 3.1 签到任务

| 字段 | 内容 |
|------|------|
| **任务类型名称** | 签到任务（连续签到/累计签到/日历签到） |
| **行为事件** | `signIn`（前端上报型） |
| **达成规则** | 连续：每天签到1次，连续N天；累计：累计签到N次；日历：特定日期签到 |
| **循环周期** | 连续：CONSECUTIVE_DAILY；累计：CUMULATIVE_RESET；日历：NO_CYCLE |
| **C端组件** | 签到日历组件（SIGN_IN_CALENDAR） |
| **事件准入规则** | 系统写死：一天只能签到一次 |
| **compatible_intents** | FREQUENCY_DROP（提升频率）、DORMANT（唤醒）、NEW_USER（养成习惯） |
| **配置项清单** | signInType（CONSECUTIVE/CUMULATIVE/CALENDAR）、signInMode（AUTO/MANUAL）、子任务里程碑配置 |

**典型子类**：
- 连续签到（非循环）：连续N天，中途断签则任务结束
- 连续循环签到：连续N天完成一轮，可多轮循环
- 累计签到（非循环）：累计N次即完成
- 累计循环签到：每累计N次循环一次，可多轮
- 日历签到（按日期）：在指定特定日期签到

---

### 3.2 浏览任务

| 字段 | 内容 |
|------|------|
| **任务类型名称** | 浏览任务 |
| **行为事件** | `view`（前端上报型，关联子任务） |
| **达成规则** | 浏览指定页面（可配时长、时段、次数） |
| **循环周期** | DAILY（最常见）/ TIME_PERIOD |
| **C端组件** | 进度条任务组件（PROGRESS_BAR_TASK） |
| **事件准入规则** | 取用户第一个未达成子任务的达成规则 |
| **compatible_intents** | CATEGORY_EXPLORE（品类探索）、NEW_USER、CHURN_RISK |
| **配置项清单** | （任务级）dailyTimeSlot；（子任务级）viewUrl、viewDurationSec、limitPerCycle |

**事件上报格式**：`{userId, taskId, subTaskId, ts}`

**达成规则示例**（领任务后浏览过该子任务绑定的页面）：
```json
{
  "eventRules": [{
    "ruleId": "r1",
    "eventKey": "view",
    "condition": {
      "type": "GROUP", "relation": "AND",
      "conditions": [
        {"type":"COMMON","key":"taskId","operator":"eq","targets":["$sys.taskId"]},
        {"type":"COMMON","key":"subTaskId","operator":"eq","targets":["$sys.subTaskId"]}
      ]
    }
  }]
}
```

---

### 3.3 分享任务

| 字段 | 内容 |
|------|------|
| **任务类型名称** | 分享任务 |
| **行为事件** | `share`（前端上报型，关联子任务） |
| **达成规则** | 分享指定内容1次（基本同浏览任务模式） |
| **循环周期** | DAILY |
| **C端组件** | 进度条任务组件 |
| **事件准入规则** | 取用户第一个未达成子任务的达成规则 |
| **compatible_intents** | CHURN_RISK（通过分享拉回）、NEW_USER（传播） |
| **配置项清单** | （子任务级）shareType、shareUrl、sharePageId、shareTitle、shareDesc、shareImageUrl |

---

### 3.4 全景下单任务

| 字段 | 内容 |
|------|------|
| **任务类型名称** | 全景下单任务（累计下单/连续下单/限时下单/满额下单） |
| **行为事件** | `quanjing`（消息触发型，全景订单事件流） |
| **达成规则** | 在指定场景/业务线累计下单N次；可加时段/金额/连续天数等条件 |
| **循环周期** | DAILY / CONSECUTIVE_DAILY / CUMULATIVE_RESET |
| **C端组件** | 进度条任务组件 |
| **事件准入规则** | 无（消息触发型，系统自动处理） |
| **compatible_intents** | PRICE_SENSITIVE（满额奖励）、FREQUENCY_DROP（提频）、DORMANT（唤醒）、CATEGORY_EXPLORE（跨品类） |
| **配置项清单** | sceneId（必填）、bizCode（业务线）、orderAmount（金额门槛）、delayJudge（延迟判定）、dailyTimeSlot（时段限制）、count（累计次数） |

**注意**：达成规则**必须**配置 `ts > $sys.taskRecvTs`（领取任务时间）。

**子类细分**（通过规则配置实现）：
- 通用下单：累计下单N次可配，延迟退单校验可配
- 美团小程序下单：可配任务领取时段 + 累计下单数 + 单笔金额
- 连续下单：每天至少下单1次，连续N天（eventContinuousDaysAtLeastOnce）
- 三餐奖励：特定时段（早/午/晚）下单

---

### 3.5 邀请助力任务

| 字段 | 内容 |
|------|------|
| **任务类型名称** | 邀请助力任务 |
| **行为事件** | `invite`（邀请人上报）+ `boost`（助力人上报），前端上报型 |
| **达成规则** | 邀请N人成功助力（邀请人视角）；助力N次成功（助力人视角） |
| **循环周期** | TIME_PERIOD（最常见）|
| **C端组件** | 邀请助力组件（INVITE_BOOST_TASK） |
| **事件准入规则** | 系统根据运营配置自动翻译，包含：邀请人/助力人次数上限 + 写死规则 |
| **compatible_intents** | NEW_USER（拉新）、CHURN_RISK（裂变唤醒）|
| **配置项清单** | inviterDailyLimit、inviterCycleLimit、boosterDailyLimit、boosterCycleLimit、allowRepeatBoostSamePerson |
| **系统写死规则** | ①邀请人不能是助力人 ②助力人同一天不能为同一人重复助力 |

**特殊性**：邀请助力任务是任务维度的事件准入规则（非子任务维度），由运营配置翻译成规则。

---

### 3.6 投票任务

| 字段 | 内容 |
|------|------|
| **任务类型名称** | 投票任务 |
| **行为事件** | `vote`（查询型）|
| **达成规则** | 用户在指定活动中完成投票 |
| **循环周期** | NO_CYCLE（一般） |
| **C端组件** | 进度条任务组件 |
| **事件准入规则** | 无（查询型不用事件准入） |
| **compatible_intents** | NEW_USER（参与感）、CATEGORY_EXPLORE（活动参与）|
| **配置项清单** | 投票接口配置、达成规则（ts > 领取时间） |

---

### 3.7 订阅提醒任务

| 字段 | 内容 |
|------|------|
| **任务类型名称** | 订阅提醒任务 |
| **行为事件** | `subscribe`（前端上报型，关联子任务） |
| **达成规则** | 订阅指定活动/服务的提醒 |
| **循环周期** | NO_CYCLE |
| **C端组件** | 进度条任务组件 |
| **事件准入规则** | 取用户第一个未达成子任务的达成规则 |
| **compatible_intents** | CHURN_RISK（保持连接）、NEW_USER |
| **配置项清单** | （子任务级）subscribeId |

---

### 3.8 组合任务（跨事件类型）

> 2.0的核心创新：**一个任务可以绑定多种事件类型**（通过任务模板实现）

| 字段 | 内容 |
|------|------|
| **任务类型名称** | 组合任务（如签到+下单、浏览+分享等） |
| **行为事件** | 多个事件类型组合（eventTypes: [signIn, quanjing]等） |
| **达成规则** | 子任务达成规则可同时配置多个事件规则 + 事件间关系 |
| **循环周期** | 视业务而定 |
| **C端组件** | 通用任务组件 |
| **compatible_intents** | 视组合意图而定 |
| **配置项清单** | 各事件类型的配置项叠加 + 事件间时序关系配置 |

**示例**：先签到后下单（签到时间 < 下单时间），利用事件间关系配置实现。

---

## 4. 原子枚举表

### 4.1 行为事件原子清单

| 事件key | 中文名 | 来源类型 | 是否关联子任务 | 是否需要配ts>领取时间 |
|--------|-------|---------|--------------|-------------------|
| signIn | 签到 | 前端上报 | 否（固定逻辑） | 否（系统自动过滤） |
| view | 浏览 | 前端上报 | 是 | 否（系统自动过滤） |
| share | 分享 | 前端上报 | 是 | 否（系统自动过滤） |
| subscribe | 订阅提醒 | 前端上报 | 是 | 否（系统自动过滤） |
| invite | 邀请 | 前端上报 | 否（任务维度） | 否 |
| boost | 助力 | 前端上报 | 否（任务维度） | 否 |
| quanjing | 全景下单 | 消息触发 | 是 | **是（必须配置）** |
| vote | 投票 | 查询型 | 是 | **是（必须配置）** |

### 4.2 奖励类型原子清单

| 奖励key | 中文名 | 发放方式 | 发奖时机选项 |
|--------|-------|---------|------------|
| COUPON | 优惠券/现金券 | prizeKey | AUTO_ON_REACH / MANUAL / DELAY_JUDGE |
| POINT | 积分/任务分 | 系统直接发 | AUTO_ON_REACH |
| VIRTUAL_GOODS | 虚拟商品（小程序金币等） | prizeKey | AUTO_ON_REACH / MANUAL |
| PHYSICAL | 实物奖励 | prizeKey | DELAY_JUDGE（需防退款） |
| NO_PRIZE | 无奖励（仅记进度） | 无 | 无 |

### 4.3 达成规则模式清单

| 规则key | 中文名 | 使用函数 | 适用事件 |
|--------|-------|---------|---------|
| COUNT_GTE | 累计次数达标 | count() >= N | 全部 |
| COUNT_EQ | 次数等于 | count() == N | 签到等 |
| CONTINUOUS_DAYS_PUSH | 连续每日（上报） | eventContinuousOnlyOnceByDay() | signIn/view/share |
| CONTINUOUS_DAYS_STREAM | 连续每日（流） | eventContinuousDaysAtLeastOnce() >= N | quanjing |
| TIME_SLOT_FILTER | 指定时段过滤 | toHHmmss(ts) btw [HH:mm:ss, HH:mm:ss] | 全部 |
| AFTER_RECV | 领取后发生 | ts > $sys.taskRecvTs | quanjing/vote（必配） |
| BIZ_CODE_FILTER | 业务线过滤 | bizCode in [...] | quanjing |
| ORDER_AMOUNT_FILTER | 订单金额过滤 | orderAmount >= N | quanjing |
| PERSONA_HIT | 命中Persona画像 | hitPersona(personaId) == 1 | 全部（领取规则中用） |
| EVENT_ORDER_RELATION | 事件时序关系 | $eventProperty.rA.ts < $eventProperty.rB.ts | 组合任务 |

### 4.4 系统内置函数清单

| 函数名 | 类型 | 语义 |
|-------|------|------|
| count() | 统计函数 | 统计事件次数 |
| toHHmmss(ts) | 普通函数 | 将时间戳转为时分秒，用于时段判断 |
| hitPersona(id) | 普通函数 | 判断用户是否命中指定画像人群包 |
| isToday(ts) | 普通函数 | 判断时间戳是否为今天 |
| eventContinuousOnlyOnceByDay() | 统计函数 | 从领取任务当天起到今天，每天有且仅有一次事件（连续上报型） |
| eventContinuousDaysAtLeastOnce() | 统计函数 | 从领取任务当天起到今天，每天至少一次，返回连续天数（流型） |
| natureDaysAgo(ts) | 统计函数 | 自然天数差计算 |

---

## 5. YAML原子组合示例

### 5.1 CHURN_RISK（流失风险用户 — 召回）

```yaml
# 意图：唤醒近30天无下单的高价值用户
# 策略：签到打卡 + 下单双重激励，快速唤醒复购行为
task_template:
  name: "N天签到+下单召回任务"
  event_types: [signIn, quanjing]
  cycle:
    type: CUMULATIVE_RESET
    max_effective_days: 14

  receive_rule:
    # 命中「近30天未下单」人群包
    conditions:
      - type: PERSONA_HIT
        personaId: "crowd_churn_risk_30d"
        operator: eq
        targets: ["1"]

  event_configs:
    signIn:
      type: CUMULATIVE

  sub_tasks:
    - title: "第1天签到"
      reach_rule:
        event_rules:
          - eventKey: signIn
            condition: {taskId: "$sys.taskId"}
            agg: count($events.r1) >= 1
      prize:
        type: COUPON
        prizeKey: "coupon_50off"
        moment: AUTO_ON_REACH

    - title: "完成一笔下单"
      reach_rule:
        event_rules:
          - eventKey: quanjing
            condition:
              sceneId: {eq: "50617"}
              ts: {gt: "$sys.taskRecvTs"}  # 必配：领取后发生
        agg: count($events.r1) >= 1
      prize:
        type: COUPON
        prizeKey: "coupon_fullreduce_20"
        moment: DELAY_JUDGE
        delay: "24h"  # 防退单延迟判定

  notification:
    trigger: ON_SUBTASK_REACH
    channel: PUSH
    title: "任务进度提醒"
    body: "恭喜完成【{subTaskTitle}】，继续加油！"
```

---

### 5.2 NEW_USER（新用户 — 培育）

```yaml
# 意图：新注册用户前7天习惯养成
# 策略：每日签到+每日浏览，培育活跃习惯
task_template:
  name: "新用户7日打卡"
  event_types: [signIn, view]
  cycle:
    type: CONSECUTIVE_DAILY
    linked_event: signIn
    max_effective_days: 7

  receive_rule:
    conditions:
      - type: PERSONA_HIT
        personaId: "crowd_new_user_7d"
        operator: eq
        targets: ["1"]

  event_configs:
    signIn:
      type: CONSECUTIVE

  sub_tasks:
    - title: "每日签到（第{day}天）"
      # 子任务x7，每天签到达成
      reach_rule:
        event_rules:
          - eventKey: signIn
            condition: {taskId: "$sys.taskId"}
            agg: count($events.r1) >= 1
      prize:
        type: POINT
        moment: AUTO_ON_REACH

    - title: "浏览推荐商品"
      # 每日浏览指定页面
      reach_rule:
        event_rules:
          - eventKey: view
            condition: {subTaskId: "$sys.subTaskId"}
            agg: count($events.r1) >= 1
      subtask_config:
        viewUrl: "https://m.meituan.com/newuser-explore"
        viewDurationSec: 5
      prize:
        type: COUPON
        prizeKey: "coupon_newuser_discount"
        moment: AUTO_ON_REACH
```

---

### 5.3 FREQUENCY_DROP（频率下降 — 提频）

```yaml
# 意图：过去14天下单频率下降用户
# 策略：每周连续下单激励
task_template:
  name: "每周下单打卡任务"
  event_types: [quanjing]
  cycle:
    type: CONSECUTIVE_DAILY
    linked_event: quanjing
    max_effective_days: 7

  receive_rule:
    conditions:
      - type: PERSONA_HIT
        personaId: "crowd_freq_drop_14d"
        operator: eq
        targets: ["1"]

  sub_tasks:
    - title: "连续下单第{N}天"
      # 子任务x7，连续每天至少下单1次
      reach_rule:
        event_rules:
          - eventKey: quanjing
            condition:
              sceneId: {eq: "50617"}
              ts: {gt: "$sys.taskRecvTs"}
            agg:
              func: eventContinuousDaysAtLeastOnce
              operator: gte
              targets: ["{N}"]  # N=1,2,3,4,5,6,7
      prize:
        type: COUPON
        prizeKey: "coupon_7day_reward"
        moment: AUTO_ON_REACH

  notification:
    trigger: ON_TASK_EXPIRE_SOON
    channel: PUSH
    title: "连续下单任务提醒"
    body: "任务还有{hours}小时到期，记得今天下单哦～"
```

---

### 5.4 DORMANT（沉默用户 — 激活）

```yaml
# 意图：90天以上未下单的沉睡用户
# 策略：低门槛邀请助力，社交驱动激活
task_template:
  name: "老友召唤任务（邀请助力）"
  event_types: [invite, boost]
  cycle:
    type: TIME_PERIOD
    period: 7  # 7天一循环

  receive_rule:
    conditions:
      - type: PERSONA_HIT
        personaId: "crowd_dormant_90d"
        operator: eq
        targets: ["1"]

  invite_boost_config:
    inviter:
      dailyLimit: 10
      cycleLimit: 30
    booster:
      dailyLimit: 5
      cycleLimit: 10
      allowRepeatBoostSamePerson: false

  sub_tasks:
    - title: "邀请3位好友助力"
      reach_rule:
        event_rules:
          - eventKey: invite
            agg: count($events.r1) >= 3
      prize:
        type: COUPON
        prizeKey: "coupon_welcome_back"
        moment: AUTO_ON_REACH

  notification:
    trigger: ON_SUBTASK_REACH
    channel: PUSH
    title: "助力成功！"
    body: "你的好友已成功助力，任务进度更新了"
```

---

### 5.5 CATEGORY_EXPLORE（品类探索 — 品类渗透）

```yaml
# 意图：只用过外卖，未使用过酒旅品类的用户
# 策略：浏览+下单双步激励
task_template:
  name: "探索新品类任务"
  event_types: [view, quanjing]
  cycle:
    type: NO_CYCLE

  receive_rule:
    conditions:
      - type: PERSONA_HIT
        personaId: "crowd_no_hotel_order"
        operator: eq
        targets: ["1"]

  sub_tasks:
    - title: "浏览酒店页面"
      reach_rule:
        event_rules:
          - eventKey: view
            condition: {subTaskId: "$sys.subTaskId"}
            agg: count($events.r1) >= 1
      subtask_config:
        viewUrl: "https://hotel.meituan.com/explore"
        viewDurationSec: 3
      prize:
        type: POINT
        moment: AUTO_ON_REACH

    - title: "完成一笔酒店订单"
      reach_rule:
        event_rules:
          - eventKey: quanjing
            condition:
              sceneId: {eq: "50617"}
              bizCode: {in: ["hotel_other", "ticket"]}
              ts: {gt: "$sys.taskRecvTs"}
            agg: count($events.r1) >= 1
      prize:
        type: COUPON
        prizeKey: "coupon_hotel_discount"
        moment: DELAY_JUDGE
        delay: "48h"

  notification:
    trigger: ON_SUBTASK_REACH
    channel: IN_APP_MSG
    body: "完成浏览任务！继续预订酒店，解锁专属优惠"
```

---

### 5.6 PRICE_SENSITIVE（价格敏感用户 — 拉高客单）

```yaml
# 意图：历史客单价偏低，引导提升消费金额
# 策略：满额下单梯度奖励
task_template:
  name: "满额下单阶梯奖励"
  event_types: [quanjing]
  cycle:
    type: CUMULATIVE_RESET
    max_effective_days: 30

  receive_rule:
    conditions:
      - type: PERSONA_HIT
        personaId: "crowd_low_avg_order"
        operator: eq
        targets: ["1"]

  sub_tasks:
    - title: "下单满50元"
      reach_rule:
        event_rules:
          - eventKey: quanjing
            condition:
              sceneId: {eq: "50617"}
              orderAmount: {gte: 50}
              ts: {gt: "$sys.taskRecvTs"}
            agg: count($events.r1) >= 1
      prize:
        type: COUPON
        prizeKey: "coupon_5yuan"
        moment: DELAY_JUDGE
        delay: "24h"

    - title: "下单满100元"
      reach_rule:
        event_rules:
          - eventKey: quanjing
            condition:
              sceneId: {eq: "50617"}
              orderAmount: {gte: 100}
              ts: {gt: "$sys.taskRecvTs"}
            agg: count($events.r1) >= 1
      prize:
        type: COUPON
        prizeKey: "coupon_15yuan"
        moment: DELAY_JUDGE
        delay: "24h"

    - title: "下单满200元"
      reach_rule:
        event_rules:
          - eventKey: quanjing
            condition:
              sceneId: {eq: "50617"}
              orderAmount: {gte: 200}
              ts: {gt: "$sys.taskRecvTs"}
            agg: count($events.r1) >= 1
      prize:
        type: COUPON
        prizeKey: "coupon_30yuan"
        moment: DELAY_JUDGE
        delay: "24h"
```

---

## 6. 规则引擎详解

### 6.1 规则结构

规则由 **若干个事件规则（必填） + 一个事件间关系（可选）** 组成。

```
规则
├── 事件规则（EventRule）[]
│   ├── 事件类型（必选）：如 signIn、quanjing
│   ├── 统计指标（可选）：统计函数（count/sum等）
│   └── 条件组（必选）
│       ├── 关系符：AND / OR
│       └── 条件[] ：左值（属性/函数）+ 运算符 + 右值
└── 事件间关系（可选）：多事件的时序/数量关系
```

### 6.2 运算符

| 运算符 | 说明 |
|-------|------|
| eq | 等于 |
| neq | 不等于 |
| gt | 大于 |
| gte | 大于等于 |
| lt | 小于 |
| lte | 小于等于 |
| in | 包含（多值） |
| notin | 不包含 |
| btw | 介于（范围） |

### 6.3 规则应用场景

| 场景 | 是否开放运营配置 | 说明 |
|------|--------------|------|
| 任务领取规则（receiveRule） | 是 | 控制哪些用户可以领取任务 |
| 子任务达成规则（reachRule） | 是 | 控制子任务何时达成 |
| 事件准入规则（admissionRule） | 否（系统根据配置自动翻译） | 控制前端上报事件是否合法 |

### 6.4 事件准入规则特殊说明

- **签到**：系统写死一天只能签到一次
- **邀请/助力**：由运营配置的次数上限等翻译成规则；另有写死规则（邀请人不能是助力人、同天同人不能重复助力）
- **浏览/分享/订阅**：取用户第一个未达成子任务的达成规则作为准入规则
- **全景下单/查询型**：无事件准入规则

---

## 7. 循环能力详解

任务2.0将循环能力开放给**所有事件类型**（1.0仅部分支持）。

| 循环方式 | key | 触发条件 | 适用场景 |
|---------|-----|---------|---------|
| 不循环 | NO_CYCLE | 默认 | 一次性任务 |
| 按时间段循环 | TIME_PERIOD | 过了有效期自动开启下一轮 | 邀请助力、每日任务 |
| 按日连续循环 | CONSECUTIVE_DAILY | 事件断签即开新一轮；完成所有子任务次日也可开新一轮 | 签到、连续下单 |
| 累计循环 | CUMULATIVE_RESET | 完成所有子任务+发奖后次日开新一轮 | 累计签到、累计下单 |

**技术约束**：连续循环和累计循环最长有效期默认60天（存储限制）。

---

## 8. 后置处理能力

子任务达成后可触发的动作：

| 动作 | 说明 | 配置字段 |
|------|------|---------|
| 发奖 | 发放奖励（券/积分/实物等） | prizeType、prizeKey、prizeMomentType |
| 发Push | 推送通知给用户 | notification配置 |
| 领取其他任务 | 关联任务，自动触发领取 | linkedTaskKey |

**发奖时机（prizeMomentType）**：
- `AUTO_ON_REACH`：达成即自动发奖（最常用）
- `MANUAL`：用户手动点击领奖
- `DELAY_JUDGE`：N小时/天后延迟判定发奖（防退单/退款）

---

<!-- （视觉渲染规则见 task-visual-rules.yaml，体用分离） -->

## 9. C端交互模式

### 9.1 任务领取方式

- 默认为**用户手动领取**（点击"去签到"/"去完成"等按钮时触发）
- 接口：`receiveAndOpUserTask`（一步合并领取+事件上报/子任务达成）

### 9.2 C端交互流程

1. 用户进入活动页面 → 调用查询任务接口（getUserTasks）
2. 用户点击任务按钮 → 调用 receiveAndOpUserTask（领取+操作合并）
3. 对于上报型事件：上报事件 → 事件准入规则校验 → 触发子任务达成判定
4. 对于查询型事件：主动查询下游接口 → 触发子任务达成判定

### 9.3 连续循环任务的特殊逻辑

- **查询任务时**：事件连续到当日**或昨日**均认为可以继续（不触发新一轮）
- **上报事件时**：事件必须连续到**今日**才可上报成功
- 设计原因：用户当天还没操作但昨天是连续的，不应在查询时就判断为断签

---

## 10. 任务模板机制

### 10.1 任务模板概念

任务模板是将**常见营销场景预配好的任务配置**固化下来，运营选择模板后：
- 自动填充该模板的所有配置项
- 少部分字段（标题、时间、奖品Key）清空可编辑
- 大部分字段（事件类型、循环方式等）**置灰不可编辑**

### 10.2 已沉淀任务模板清单

| 模板名 | 事件类型 | 循环方式 |
|-------|---------|---------|
| 连续签到模板 | signIn | CONSECUTIVE_DAILY |
| 累计签到模板 | signIn | CUMULATIVE_RESET |
| 日历签到模板 | signIn | NO_CYCLE |
| 浏览页面模板 | view | DAILY |
| 分享页面模板 | share | DAILY |
| 邀请助力模板 | invite+boost | TIME_PERIOD |
| 全景下单模板 | quanjing | DAILY |
| 全景下单延迟判定模板 | quanjing | DAILY |
| 全景连续下单模板 | quanjing | CONSECUTIVE_DAILY |

### 10.3 模板字段可编辑规则

```json
// 以累计签到模板为例
{
  "$.eventTypes": "FORBIDDEN",              // 事件类型不可改
  "$.eventConfigs.signIn.type": "FORBIDDEN", // 签到类型不可改
  "$.receiveRule.cycleType": "FORBIDDEN",   // 循环方式不可改
  "$.subTasks[*].commonConfig.reachCountLimit": "FORBIDDEN",
  // 以下统一清空且可编辑
  "$.taskId": "EDITABLE_EMPTY",
  "$.title": "EDITABLE_EMPTY",
  "$.startTime": "EDITABLE_EMPTY",
  "$.endTime": "EDITABLE_EMPTY",
  "$.subTasks[*].prizeKey": "EDITABLE_EMPTY"
}
```

---

## 附录：关键发现与设计要点

### 发现1：6个原子的映射关系

```
行为事件  ←→  action_atoms（signIn/view/share/quanjing/invite/boost/subscribe/vote）
达成规则  ←→  rule_patterns（COUNT_GTE/CONTINUOUS_DAYS/TIME_SLOT/PERSONA_HIT等）
奖励类型  ←→  reward_atoms（COUPON/POINT/VIRTUAL_GOODS/NO_PRIZE）
触达时机  ←→  notification_atoms（ON_REACH/ON_FINISH/ON_EXPIRE）
文案模板  ←→  copy_atoms（任务标题/子任务标题/CTA文案/Push内容）
人群条件  ←→  audience_atoms（PERSONA_CROWD/NEW_USER/VIP_LEVEL/ALL_USERS）
```

### 发现2：浅通用的实现机制

"不改代码只加配置"的核心是**规则引擎**：
- 规则 = 若干EventRule + 事件间关系
- EventRule = 事件类型 + 条件组 + 聚合条件
- 条件 = 左值（属性/函数） + 运算符 + 右值

新业务接入只需：定义新事件类型Schema + 开发对应函数（如有） + 配置规则YAML。

### 发现3：三类事件准入规则处理策略不同

| 事件类 | 准入规则来源 | 可否运营直接配置 |
|-------|------------|---------------|
| 签到 | 系统写死（1天1次） | 否 |
| 邀请/助力 | 运营配置→系统翻译 | 间接（通过配置项翻译） |
| 浏览/分享/订阅 | 关联子任务达成规则 | 间接（通过子任务规则） |
| 消息触发/查询型 | 无准入规则 | — |

### 发现4：连续循环的"昨日容错"设计

查询任务时，允许"事件连续到昨日"也视为正常（不开启新轮），主要防止：用户当天还没操作就被判断为断签需重新领取。

### 发现5：1.0任务类型→2.0事件类型映射

文档明确提到1.0有50+种任务类型，全部通过以下5种基础事件类型（+规则配置）覆盖：
**signIn / view / share / quanjing / invite+boost**（投票/订阅在2.0新增）

复杂业务场景通过规则配置（sceneId/bizCode/金额/时段/画像/连续天数等）组合实现，无需新增代码。
