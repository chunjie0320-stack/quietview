---
name: claw-agent-memory
description: >
  OpenClaw 持久化记忆系统（独立版）。使用 Cloudflare Workers AI 做语义向量化，本地 SQLite + CF D1 双写，无需美团内网，任何环境均可使用。
  对话中遇到用户偏好、决策、纠正、约束时，遵循 WAL 协议：先调 vm_remember 写入记忆，再回答。
  会话开始时建议用 vm_recall 召回相关上下文；spawn 子 agent 前用 vm_recall --global 注入全局记忆。
  与原生 memory_search 互补：原生工具索引 Markdown 日志，本技能管理高价值结构化记忆（决策/偏好/教训）。

metadata:
  skillhub.creator: "zhengchunjie"
  skillhub.version: "V2"
---

# claw-agent-memory 🧠

**OpenClaw 的持久化智能记忆系统（独立版）。**  
WAL 协议 + bge-m3 向量搜索 + CF D1 云端持久化 + 子 agent 隔离。

> **与 agent-memory（原版）的核心区别**：原版绑定美团内网 API，离开公司就废了；本版完全基于 Cloudflare，只要有网就能用，记忆不会随沙箱重置丢失。

---

## 场景对比：claw-agent-memory vs agent-memory（原版）

### 场景1：换了公司，还想让 AI 记住你的习惯

- **agent-memory（原版）**：❌ 直接废了。嵌入 API 是美团内网地址，离职后连不上，所有记忆功能失效。
- **claw-agent-memory**：✅ 照常用。用 Cloudflare 服务，只要有网就能跑，跟公司网络没关系。

### 场景2：沙箱机器重置了，记忆还在吗？

- **agent-memory（原版）**：❌ 全丢。记忆只存在沙箱本地 SQLite，机器一重置就消失。
- **claw-agent-memory**：✅ 不丢。本地 SQLite + CF D1 云端双写，沙箱没了从云端恢复，`vm-sync --pull` 一条命令拉回来。

### 场景3：你说"以后周报结论放第一行"，下次还记得吗？

- **agent-memory（原版）**：⚠️ 看运气。有 WAL 协议设计，但没有接入行为规范，可能漏存。
- **claw-agent-memory**：✅ 有保障。偏好类信息触发 WAL 协议——先写向量库再回答，沙箱崩溃也不会丢。

### 场景4：搜"上次讨论过什么投资框架"

- **agent-memory（原版）**：语义质量好（1536维，OpenAI text-embedding-3），找得准；但依赖美团内网。
- **claw-agent-memory**：语义同样准（bge-m3，1024维，专为多语言优化）；无需内网，中文场景不输原版。

### 场景5：记忆库越积越多，怎么清理？

- **agent-memory（原版）**：❌ 没有工具，只能手动进数据库删。
- **claw-agent-memory**：✅ `vm-health --report` 直接显示哪些记忆重复了、哪些超180天没用了，自己决定要不要删。

### 场景6：新开一个会话，AI 还知道你的项目背景吗？

- **agent-memory（原版）**：❌ 没有热身机制，每次新会话都是白板。
- **claw-agent-memory**：✅ `vm-warmup.sh "当前话题"` 根据话题语义召回最相关记忆，新会话 AI 直接知道你的偏好和进展。

---

## 核心能力一览

| 能力 | 说明 |
|------|------|
| 🧠 语义向量搜索 | bge-m3（1024维），中文语义理解，不需要精确关键词 |
| ☁️ 云端持久化 | 本地 SQLite + CF D1 双写，沙箱重置不丢记忆 |
| 🔄 双向同步 | `vm-sync --push/pull/status` |
| 🏥 记忆健康检查 | `vm-health --report`，识别重复/过期记忆 |
| 🔥 会话热身 | `vm-warmup.sh`，新会话快速注入上下文 |
| 🔒 子 agent 隔离 | 全局库 + 子 agent 专属库，互不干扰 |
| ⚡ WAL 协议 | 先写记忆再回答，防会话中断丢失 |

---

## 快速开始

### 1. 前置条件

需要一个 Cloudflare 账号（免费），创建：
- **Workers AI**：用于 bge-m3 向量化（免费额度 10,000 次/天）
- **D1 数据库**：用于云端持久化（免费额度充裕）
- **API Token**：权限包含 `AI:Read`、`D1:Edit`

### 2. 配置文件

创建 `~/.openclaw/memory/config.json`：
```json
{
  "defaultModel": "bge-m3",
  "models": {
    "bge-small": { "cfModel": "@cf/baai/bge-small-en-v1.5", "dimensions": 384 },
    "bge-m3":    { "cfModel": "@cf/baai/bge-m3",            "dimensions": 1024 }
  },
  "d1": {
    "accountId":  "你的CF账号ID",
    "databaseId": "你的D1数据库ID",
    "token":      "你的CF API Token"
  },
  "proxy": "http://127.0.0.1:8118"
}
```

### 3. 初始化本地数据库
```bash
node ~/.openclaw/skills/agent-memory/scripts/vm-init.js
```

---

## 核心工具

### `vm_remember` — 写入记忆
```bash
node ~/.openclaw/skills/agent-memory/scripts/vm-remember.js \
  "用户偏好 Tailwind 而非 vanilla CSS" \
  --key "preference/css" \
  --importance 0.9
```

| 参数 | 说明 | 默认 |
|------|------|------|
| `<content>` | 要记住的内容 | 必填 |
| `--key <tag>` | 语义标签，相同 key 则更新不重复插入 | 空 |
| `--importance <0-1>` | 重要程度，影响排序 | 0.7 |
| `--agent <id>` | 存入子 agent 专属库 | 全局库 |
| `--model bge-m3` | 指定模型 | bge-m3 |

### `vm_recall` — 语义召回
```bash
node ~/.openclaw/skills/agent-memory/scripts/vm-recall.js \
  "用户的技术偏好" --limit 5
```

| 参数 | 说明 | 默认 |
|------|------|------|
| `<query>` | 自然语言查询 | 必填 |
| `--limit <N>` | 返回条数 | 5 |
| `--threshold <0-1>` | 相似度阈值 | 0.3 |
| `--global` | 只搜全局库 | - |
| `--json` | JSON 格式输出 | - |

### `vm-sync` — 云端同步
```bash
node ~/.openclaw/skills/agent-memory/scripts/vm-sync.js --status  # 查看同步状态
node ~/.openclaw/skills/agent-memory/scripts/vm-sync.js --push    # 本地→D1
node ~/.openclaw/skills/agent-memory/scripts/vm-sync.js --pull    # D1→本地（沙箱重置后恢复用）
```

### `vm-health` — 记忆健康检查
```bash
node ~/.openclaw/skills/agent-memory/scripts/vm-health.js --status      # 基本统计
node ~/.openclaw/skills/agent-memory/scripts/vm-health.js --duplicates  # 找重复记忆
node ~/.openclaw/skills/agent-memory/scripts/vm-health.js --stale       # 找超期记忆（>180天未用）
node ~/.openclaw/skills/agent-memory/scripts/vm-health.js --report      # 完整报告
```

---

## WAL 协议：先写后答

遇到以下场景，**先调 `vm_remember` 写入，再回答**：

| 场景 | key 前缀 | importance |
|------|----------|------------|
| 用户表达偏好 | `preference/` | 0.9 |
| 用户做决策 | `decision/` | 0.85 |
| 用户纠正你 | `lesson/` | 0.95 |
| 用户给约束/截止日 | `constraint/` | 0.8 |
| 里程碑完成 | `milestone/` | 0.75 |

**为什么先写？** 先回答后崩溃（上下文压缩、会话断开），信息永久丢失；先写入则崩溃无损。

---

## 子 Agent 记忆隔离

```
~/.openclaw/memory/
├── vectors.db          # 全局共享库（主 agent 写入）
├── <agentId>/
│   └── vectors.db      # 子 agent 专属库
└── config.json
```

Spawn 子 agent 前注入全局上下文：
```bash
CTX=$(node ~/.openclaw/skills/agent-memory/scripts/vm-recall.js "子任务主题" --limit 5 --global)
# 子 agent 内写入专属库
node vm-remember.js "子任务决策" --agent $OPENCLAW_AGENT_ID --key task/decision
```

---

## 与 OpenClaw 原生记忆的协同

- **原生 `memory_search`**：自动索引 Markdown 日志，适合模糊回忆"上次聊过什么"
- **claw-agent-memory**：主动写入的结构化记忆，适合精确召回"用户的偏好/决策/教训"
- **最佳实践**：两者同时用，互补不替代

---

## 故障排查

| 问题 | 解决方案 |
|------|----------|
| `config.json not found` | 创建 `~/.openclaw/memory/config.json`（见快速开始） |
| `vectors.db not found` | 运行 `node vm-init.js` |
| D1 写入失败 | 检查 CF Token 权限是否包含 D1:Edit |
| 向量化失败 | 检查 CF Token 是否包含 AI:Read；确认代理配置正确 |
| 本地与云端不一致 | 运行 `vm-sync --status` 查看差异，再决定 push 还是 pull |

---

## 性能与调用量影响

**结论：对普通对话无影响，仅在触发记忆场景时有轻微延迟。**

### 何时会产生 API 调用？

| 操作 | 触发条件 | 调用数 |
|------|----------|--------|
| `vm_remember` | 遇到用户偏好/决策/纠正/约束（WAL 协议触发） | CF Workers AI × 1 + CF D1 × 1 |
| `vm_recall` | 会话开始语义热身，或 spawn 子 agent 前 | CF Workers AI × 1 |
| `vm-sync` | 手动或定时同步 | CF D1 × N（按记忆条数） |

### 延迟影响

- `vm_remember`：额外延迟约 **300–800ms**（CF 向量化 + D1 写入）
- `vm_recall`：额外延迟约 **200–500ms**（CF 向量化 + 本地余弦计算）
- 普通对话（无记忆触发）：**0 影响**

### CF 免费额度（个人用户完全够用）

| 服务 | 免费额度 |
|------|----------|
| Workers AI（向量化） | 10,000 次/天 |
| D1 读取 | 50,000 次/天 |
| D1 写入 | 50,000 次/天 |

每次记忆写入消耗 Workers AI 1 次 + D1 1 次，正常对话每天触发不超过数十次，远低于免费上限。
