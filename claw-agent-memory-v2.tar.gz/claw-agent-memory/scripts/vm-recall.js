#!/usr/bin/env node

/**
 * vm-recall.js — 语义搜索记忆（本地SQLite优先，D1 fallback）
 *
 * 用法:
 *   node vm-recall.js <query> [选项]
 *
 * 选项:
 *   --limit <N>         返回条数，默认 5
 *   --threshold <0-1>   相似度阈值，默认 0.3
 *   --model <name>      嵌入模型：bge-small | bge-m3（需与存储时一致）
 *   --appid <id>        AppId（优先于环境变量 FRIDAY_APP_ID）
 *   --key <tag>         仅搜索指定标签前缀（如 preference/）
 *   --json              输出 JSON 格式（供程序调用）
 *   --from-d1           强制从 D1 搜索（跳过本地）
 *
 * 示例:
 *   node vm-recall.js "用户的技术偏好" --limit 5
 *   node vm-recall.js "CSS 框架选择" --key preference/
 *   node vm-recall.js "最近的决策" --json
 */

'use strict';

const fs    = require('fs');
const path  = require('path');
const https = require('https');
const HttpsProxyAgent = require('https-proxy-agent');

// ── 路径配置 ────────────────────────────────────────────────────────────────
const MEMORY_DIR  = path.join(process.env.HOME, '.openclaw', 'memory');
const CONFIG_PATH = path.join(MEMORY_DIR, 'config.json');

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    }
  } catch {}
  return {
    defaultModel: 'bge-m3',
    models: {
      'bge-small': { cfModel: '@cf/baai/bge-small-en-v1.5', dimensions: 384 },
      'bge-m3':    { cfModel: '@cf/baai/bge-m3',            dimensions: 1024 },
    },
    d1: {
      accountId:  '02098f6fe516b7886e79e03150a2ece4',
      databaseId: '44787f93-24e5-4f2b-9f74-c178e42dc102',
      token:      'cfut_GrSgTWTMF1hv4SBzd0V8MvdN8xHL8nv7H0RLB6By52e5a1ac',
    },
    proxy: 'http://127.0.0.1:8118',
  };
}

const CONFIG = loadConfig();
const CF_PROXY = process.env.HTTPS_PROXY || process.env.https_proxy || CONFIG.proxy || '';

function getDbPath(agentId) {
  if (agentId) return path.join(MEMORY_DIR, agentId, 'vectors.db');
  return path.join(MEMORY_DIR, 'vectors.db');
}

function resolveModel(alias) {
  const models = CONFIG.models || {};
  if (models[alias]) return models[alias].cfModel;
  if (alias.startsWith('@cf/') || alias.startsWith('@hf/')) return alias;
  return models['bge-small']?.cfModel || '@cf/baai/bge-small-en-v1.5';
}

// ── 参数解析 ────────────────────────────────────────────────────────────────
function parseArgs(argv) {
  const args = argv.slice(2);
  const result = {
    query:      null,
    limit:      5,
    threshold:  0.3,
    model:      CONFIG.defaultModel || 'bge-small',
    appid:      null,
    key:        null,
    agent:      process.env.OPENCLAW_AGENT_ID || null,
    globalOnly: false,
    json:       false,
    fromD1:     false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    if (arg.startsWith('--')) {
      const flag = arg.slice(2);
      const val  = args[i + 1];
      switch (flag) {
        case 'limit':     result.limit = parseInt(val, 10); i += 2; break;
        case 'threshold': result.threshold = parseFloat(val); i += 2; break;
        case 'model':     result.model = val; i += 2; break;
        case 'appid':     result.appid = val; i += 2; break;
        case 'key':       result.key = val; i += 2; break;
        case 'agent':     result.agent = val; i += 2; break;
        case 'global':    result.globalOnly = true; i++; break;
        case 'json':      result.json = true; i++; break;
        case 'from-d1':   result.fromD1 = true; i++; break;
        default: i++;
      }
    } else {
      if (!result.query) result.query = arg;
      i++;
    }
  }
  return result;
}

// ── CF Workers AI 嵌入 API ───────────────────────────────────────────────────
function embed(text, modelAlias) {
  return new Promise((resolve, reject) => {
    const cfModel = resolveModel(modelAlias);
    const url = `https://api.cloudflare.com/client/v4/accounts/${CONFIG.d1.accountId}/ai/run/${cfModel}`;
    const body = JSON.stringify({ text: [text] });
    const parsedUrl = new URL(url);

    const options = {
      hostname: parsedUrl.hostname,
      path:     parsedUrl.pathname,
      method:   'POST',
      headers: {
        'Authorization': `Bearer ${CONFIG.d1.token}`,
        'Content-Type':  'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
      ...(CF_PROXY ? { agent: new HttpsProxyAgent(CF_PROXY) } : {}),
    };

    const req = https.request(options, res => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json.error) {
            reject(new Error(`API 错误: ${json.error.message || JSON.stringify(json.error)}`));
          } else if (json.result && json.result.data && json.result.data[0]) {
            resolve(json.result.data[0]);
          } else {
            reject(new Error(`响应格式异常: ${data}`));
          }
        } catch (e) {
          reject(new Error(`JSON 解析失败: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── CF D1 API 调用 ────────────────────────────────────────────────────────────
function d1Query(sql, params) {
  params = params || [];
  return new Promise((resolve, reject) => {
    const { accountId, databaseId, token } = CONFIG.d1;
    const url = `https://api.cloudflare.com/client/v4/accounts/${accountId}/d1/database/${databaseId}/query`;
    const body = JSON.stringify({ sql, params });
    const parsedUrl = new URL(url);

    const options = {
      hostname: parsedUrl.hostname,
      path:     parsedUrl.pathname,
      method:   'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type':  'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
      ...(CF_PROXY ? { agent: new HttpsProxyAgent(CF_PROXY) } : {}),
    };

    const req = https.request(options, res => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (!json.success) {
            reject(new Error(`D1 错误: ${JSON.stringify(json.errors)}`));
          } else {
            resolve(json.result);
          }
        } catch (e) {
          reject(new Error(`D1 JSON 解析失败: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── 向量反序列化 ─────────────────────────────────────────────────────────────
function blobToVector(blob) {
  const buf = Buffer.isBuffer(blob) ? blob : Buffer.from(blob);
  return new Float32Array(buf.buffer, buf.byteOffset, buf.byteLength / 4);
}

// ── 余弦相似度 ────────────────────────────────────────────────────────────────
function cosineSimilarity(a, b) {
  if (a.length !== b.length) return 0;
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot   += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

function recencyDecay(createdAt) {
  if (!createdAt) return 1.0;
  // 支持 Unix timestamp（整数）和 ISO 字符串
  const ts = typeof createdAt === 'number'
    ? createdAt * 1000
    : new Date(createdAt).getTime();
  const ageDays = (Date.now() - ts) / (1000 * 60 * 60 * 24);
  return Math.pow(0.5, ageDays / 30);
}

function weightedScore(similarity, importance, createdAt) {
  const imp = Math.min(1, Math.max(0, importance || 0.7));
  return similarity * (0.6 + 0.4 * imp) * recencyDecay(createdAt);
}

// ── 本地 SQLite 搜索 ─────────────────────────────────────────────────────────
async function loadDb(initSqlJs, dbPath) {
  if (!fs.existsSync(dbPath)) return null;
  const SQL      = await initSqlJs();
  const fileData = fs.readFileSync(dbPath);
  return new SQL.Database(fileData);
}

function searchDb(db, queryF32, keyFilter, threshold, source) {
  if (!db) return [];
  let sql    = 'SELECT id, content, embedding, key, importance, metadata, created_at FROM memories';
  let params = [];
  if (keyFilter) {
    sql += ' WHERE key LIKE ?';
    params.push(`${keyFilter}%`);
  }
  const results = db.exec(sql, params);
  if (!results.length || !results[0].values.length) return [];

  return results[0].values
    .map(([id, content, embBlob, key, importance, metadata, createdAt]) => {
      if (!embBlob) return null;
      const vec   = blobToVector(embBlob);
      if (vec.length !== queryF32.length) return null; // 模型维度不匹配跳过
      const sim   = cosineSimilarity(queryF32, vec);
      const score = weightedScore(sim, importance, createdAt);
      return { id, content, key, importance, metadata, createdAt, score, sim, source };
    })
    .filter(r => r !== null && r.sim >= threshold);
}

// ── D1 远端搜索（全量拉取+本地计算相似度）────────────────────────────────────
async function searchD1(queryF32, keyFilter, threshold, agentId, limit) {
  try {
    let sql = 'SELECT id, content, vector, key, importance, metadata, created_at, agent_id FROM memories';
    const params = [];
    const conditions = [];

    if (keyFilter) {
      conditions.push('key LIKE ?');
      params.push(`${keyFilter}%`);
    }
    if (agentId) {
      conditions.push('agent_id = ?');
      params.push(agentId);
    }
    if (conditions.length > 0) {
      sql += ' WHERE ' + conditions.join(' AND ');
    }
    sql += ` LIMIT ${limit * 10}`; // 拉取更多供本地排序

    const res = await d1Query(sql, params);
    if (!res || !res[0] || !res[0].results) return [];

    return res[0].results
      .map(row => {
        if (!row.vector) return null;
        let vecArr;
        try {
          vecArr = JSON.parse(row.vector);
        } catch { return null; }
        const vec = new Float32Array(vecArr);
        if (vec.length !== queryF32.length) return null;
        const sim   = cosineSimilarity(queryF32, vec);
        const score = weightedScore(sim, row.importance, row.created_at);
        return {
          id: row.id, content: row.content, key: row.key,
          importance: row.importance, metadata: row.metadata,
          createdAt: row.created_at, score, sim, source: 'd1-' + (row.agent_id || 'global'),
        };
      })
      .filter(r => r !== null && r.sim >= threshold);
  } catch (e) {
    return [];
  }
}

// ── 主流程 ──────────────────────────────────────────────────────────────────
async function main() {
  const opts = parseArgs(process.argv);

  if (!opts.query) {
    console.error('用法: node vm-recall.js <query> [--limit 5] [--threshold 0.3] [--model bge-small|bge-m3]');
    process.exit(1);
  }

  let initSqlJs;
  try {
    initSqlJs = require('sql.js');
  } catch {
    console.error('✗ 未找到 sql.js，请在技能目录运行: npm install');
    process.exit(1);
  }

  if (!opts.json) process.stdout.write(`🔍 向量化查询（${opts.model}）...`);
  let queryVec;
  try {
    queryVec = await embed(opts.query, opts.model);
    if (!opts.json) console.log(` ✓`);
  } catch (e) {
    if (!opts.json) console.error(`\n✗ 嵌入 API 调用失败: ${e.message}`);
    process.exit(1);
  }
  const queryF32 = new Float32Array(queryVec);

  let merged = [];

  if (!opts.fromD1) {
    // ── 优先读本地 SQLite ──────────────────────────────────────────────────
    const globalDbPath = getDbPath(null);
    const agentDbPath  = (!opts.globalOnly && opts.agent) ? getDbPath(opts.agent) : null;

    const globalDb = await loadDb(initSqlJs, globalDbPath);
    const agentDb  = agentDbPath ? await loadDb(initSqlJs, agentDbPath) : null;

    const globalHits = searchDb(globalDb, queryF32, opts.key, opts.threshold, 'local-global');
    const agentHits  = searchDb(agentDb,  queryF32, opts.key, opts.threshold, `local-${opts.agent || 'agent'}`);

    if (globalDb) globalDb.close();
    if (agentDb)  agentDb.close();

    const localCount = globalHits.length + agentHits.length;

    // 合并本地结果
    const seen = new Set();
    const localMerged = [...globalHits, ...agentHits]
      .filter(r => { if (seen.has(r.id)) return false; seen.add(r.id); return true; })
      .sort((a, b) => b.score - a.score);

    if (localCount > 0) {
      // 本地有数据，直接用
      merged = localMerged.slice(0, opts.limit);
      if (!opts.json) {
        process.stdout.write(`📍 本地命中 ${localCount} 条\n`);
      }
    } else {
      // 本地无数据，fallback 到 D1
      if (!opts.json) process.stdout.write(`📍 本地无数据，fallback 到 D1...`);
      const d1Hits = await searchD1(queryF32, opts.key, opts.threshold, opts.agent, opts.limit);
      if (!opts.json) console.log(` D1 命中 ${d1Hits.length} 条`);
      merged = d1Hits
        .sort((a, b) => b.score - a.score)
        .slice(0, opts.limit);
    }
  } else {
    // 强制从 D1 搜索
    if (!opts.json) process.stdout.write(`☁️  从 D1 搜索...`);
    const d1Hits = await searchD1(queryF32, opts.key, opts.threshold, opts.agent, opts.limit);
    if (!opts.json) console.log(` D1 命中 ${d1Hits.length} 条`);
    merged = d1Hits
      .sort((a, b) => b.score - a.score)
      .slice(0, opts.limit);
  }

  if (!merged.length) {
    if (opts.json) {
      console.log(JSON.stringify({ results: [], query: opts.query, threshold: opts.threshold }));
    } else {
      console.log(`💭 未找到相似度 >= ${opts.threshold} 的记忆。`);
      console.log('   提示: 降低 --threshold 可获得更多结果');
    }
    return;
  }

  if (opts.json) {
    console.log(JSON.stringify({
      query: opts.query,
      results: merged.map(r => ({
        id:         r.id,
        content:    r.content,
        key:        r.key,
        importance: r.importance,
        score:      Math.round(r.score * 1000) / 1000,
        sim:        Math.round(r.sim * 1000) / 1000,
        source:     r.source,
        created_at: r.createdAt,
      })),
    }));
  } else {
    console.log(`\n🧠 找到 ${merged.length} 条相关记忆（查询: "${opts.query}"）\n`);
    merged.forEach((r, i) => {
      const keyStr  = r.key ? ` [${r.key}]` : '';
      const simPct  = (r.sim * 100).toFixed(1);
      const date    = r.createdAt
        ? (typeof r.createdAt === 'number'
          ? new Date(r.createdAt * 1000).toISOString().split('T')[0]
          : r.createdAt.split('T')[0])
        : '';
      const srcMark = r.source !== 'local-global' ? ` 📦${r.source}` : '';
      console.log(`${i + 1}.${keyStr}${srcMark} (相似${simPct}% 重要性:${r.importance} ${date})`);
      console.log(`   ${r.content}`);
      console.log();
    });
  }
}

main().catch(err => {
  console.error('✗ 执行失败:', err.message);
  process.exit(1);
});
