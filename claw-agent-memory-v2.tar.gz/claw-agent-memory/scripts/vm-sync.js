#!/usr/bin/env node
/**
 * vm-sync.js — 本地SQLite ↔ CF D1 双向同步
 * 用法:
 *   node vm-sync.js --status   # 显示本地和D1的记录数对比
 *   node vm-sync.js --push     # 本地 → D1
 *   node vm-sync.js --pull     # D1 → 本地
 */
'use strict';
const fs    = require('fs');
const path  = require('path');
const https = require('https');
const HttpsProxyAgent = require('https-proxy-agent');

const SKILL_DIR  = path.join(process.env.HOME, '.openclaw', 'skills', 'agent-memory');
const MEMORY_DIR = path.join(process.env.HOME, '.openclaw', 'memory');
const DB_PATH    = path.join(MEMORY_DIR, 'vectors.db');

const CONFIG = {
  d1: {
    accountId:  '02098f6fe516b7886e79e03150a2ece4',
    databaseId: '44787f93-24e5-4f2b-9f74-c178e42dc102',
    token:      'cfut_GrSgTWTMF1hv4SBzd0V8MvdN8xHL8nv7H0RLB6By52e5a1ac',
  },
  proxy: 'http://127.0.0.1:8118',
};
const CF_PROXY = process.env.HTTPS_PROXY || process.env.https_proxy || CONFIG.proxy || '';

function d1Query(sql, params = []) {
  return new Promise((resolve, reject) => {
    const { accountId, databaseId, token } = CONFIG.d1;
    const url  = `https://api.cloudflare.com/client/v4/accounts/${accountId}/d1/database/${databaseId}/query`;
    const body = JSON.stringify({ sql, params });
    const parsed = new URL(url);
    const options = {
      hostname: parsed.hostname, path: parsed.pathname, method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      ...(CF_PROXY ? { agent: new HttpsProxyAgent(CF_PROXY) } : {}),
    };
    const req = https.request(options, res => {
      let data = '';
      res.on('data', c => { data += c; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (!json.success) reject(new Error('D1错误: ' + JSON.stringify(json.errors)));
          else resolve(json.result && json.result[0] ? json.result[0] : {});
        } catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.write(body); req.end();
  });
}

async function loadLocalDb() {
  const initSqlJs = require(path.join(SKILL_DIR, 'node_modules', 'sql.js'));
  const SQL = await initSqlJs();
  if (!fs.existsSync(DB_PATH)) return null;
  const fileData = fs.readFileSync(DB_PATH);
  return new SQL.Database(fileData);
}

async function cmdStatus() {
  console.log('\n📊 记忆库状态对比\n');
  let localCount = 0;
  const db = await loadLocalDb();
  if (db) {
    const res = db.exec('SELECT COUNT(*) as c FROM memories');
    localCount = res[0] && res[0].values[0][0] || 0;
    db.close();
  }
  const d1Result = await d1Query('SELECT COUNT(*) as c FROM memories');
  const d1Count  = d1Result.results && d1Result.results[0] ? d1Result.results[0].c : 0;
  console.log('  本地 SQLite : ' + localCount + ' 条');
  console.log('  CF D1 云端  : ' + d1Count + ' 条');
  const diff = Math.abs(localCount - d1Count);
  if (diff === 0) console.log('  ✅ 已同步\n');
  else if (localCount > d1Count) console.log('  💡 本地比D1多 ' + diff + ' 条，运行 --push 同步到云端\n');
  else console.log('  💡 D1比本地多 ' + diff + ' 条，运行 --pull 同步到本地\n');
}

async function cmdPush() {
  console.log('\n⬆️  推送本地记忆到D1...\n');
  const db = await loadLocalDb();
  if (!db) { console.error('本地vectors.db不存在'); process.exit(1); }
  const res = db.exec('SELECT id, key, content, embedding, importance, created_at, updated_at, metadata, model FROM memories');
  db.close();
  if (!res[0]) { console.log('  本地无记录'); return; }
  const cols = res[0].columns;
  const rows = res[0].values.map(v => {
    const r = {};
    cols.forEach((c,i) => r[c] = v[i]);
    return r;
  });
  const d1Existing = await d1Query('SELECT id FROM memories');
  const d1Ids = new Set((d1Existing.results || []).map(r => r.id));
  const toInsert = rows.filter(r => !d1Ids.has(r.id));
  console.log('  本地 ' + rows.length + ' 条，D1已有 ' + d1Ids.size + ' 条，推送 ' + toInsert.length + ' 条\n');
  let ok = 0, fail = 0;
  for (const r of toInsert) {
    try {
      // embedding是Buffer，转为JSON数组存到vector列
      let vectorJson = '[]';
      if (r.embedding) {
        const buf = Buffer.from(r.embedding);
        const arr = [];
        for (let i = 0; i < buf.length; i += 4) arr.push(buf.readFloatLE(i));
        vectorJson = JSON.stringify(arr);
      }
      const ts = r.created_at ? Math.floor(new Date(r.created_at).getTime()/1000) : Date.now()/1000|0;
      await d1Query(
        'INSERT OR IGNORE INTO memories (id,key,content,vector,importance,created_at,updated_at,agent_id,metadata,model) VALUES (?,?,?,?,?,?,?,?,?,?)',
        [r.id, r.key||'', r.content, vectorJson, r.importance||0.7, ts, ts, 'global', r.metadata||'{}', r.model||'bge-small']
      );
      ok++; process.stdout.write('  ✓ [' + (r.key||'') + ']\n');
    } catch (e) { fail++; process.stdout.write('  ✗ ' + e.message + '\n'); }
  }
  console.log('\n  成功 ' + ok + ' 条，失败 ' + fail + ' 条');
}

async function main() {
  const cmd = process.argv[2] || '--status';
  try {
    if (cmd === '--status') await cmdStatus();
    else if (cmd === '--push') await cmdPush();
    else if (cmd === '--pull') console.log('--pull 功能开发中，建议直接用 vm-sync --push 保持本地为主源');
    else if (cmd === '--full') await cmdPush();
    else console.log('用法: node vm-sync.js [--status|--push|--pull]');
  } catch (e) { console.error('错误:', e.message); process.exit(1); }
}
main();
