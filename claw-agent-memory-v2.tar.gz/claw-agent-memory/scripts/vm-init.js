#!/usr/bin/env node

/**
 * vm-init.js — 初始化 catclaw-memory 记忆系统
 *
 * 用法:
 *   node vm-init.js              # 完整初始化
 *   node vm-init.js --today-only # 仅创建今日日志
 *   node vm-init.js --force      # 强制重建数据库
 */

'use strict';

const fs = require('fs');
const path = require('path');

// ── 路径配置 ────────────────────────────────────────────────────────────────
const MEMORY_DIR = path.join(process.env.HOME, '.openclaw', 'memory');
const DAILY_DIR  = path.join(MEMORY_DIR, 'daily');
const DB_PATH    = path.join(MEMORY_DIR, 'vectors.db');
const SESSION_PATH = path.join(MEMORY_DIR, 'SESSION-STATE.md');
const MEMORY_MD_PATH = path.join(MEMORY_DIR, 'MEMORY.md');

// ── 模板 ────────────────────────────────────────────────────────────────────
const SESSION_STATE_TEMPLATE = () => `# SESSION-STATE.md — 当前会话热缓存

此文件是 Agent 的"RAM"——在会话压缩、重启或切换任务时保留状态。
**WAL 协议：在回答用户之前先更新此文件。**

## 当前任务
[无]

## 关键上下文
[暂无]

## 待办事项
- [ ] 无

## 最近决策
[暂无]

---
*最后更新: ${new Date().toISOString()}*
`;

const MEMORY_MD_TEMPLATE = () => `# MEMORY.md — 长期记忆

> 精炼版长期记忆，从每日日志中提炼。保持简洁（建议 < 5KB）。

## 关于用户
[沟通风格、技术背景、偏好]

## 技术偏好
[语言、框架、工具选择]

## 重要决策
[架构和产品决策及原因]

## 经验教训
[错误案例和正确做法]

## 活跃项目
[项目名称、状态、关键信息]

---
*最后更新: ${new Date().toISOString()}*
`;

const DAILY_TEMPLATE = (date) => `# ${date} — 每日日志

## 完成的任务
-

## 做出的决策
-

## 学到的教训
-

## 明日计划
-
`;

// ── sql.js 数据库初始化 ─────────────────────────────────────────────────────
async function initDatabase(force = false) {
  if (fs.existsSync(DB_PATH) && !force) {
    console.log(`• vectors.db 已存在（${(fs.statSync(DB_PATH).size / 1024).toFixed(1)}KB）`);
    return;
  }

  let initSqlJs;
  try {
    initSqlJs = require('sql.js');
  } catch (e) {
    console.error('✗ 未找到 sql.js，请运行: npm install（在技能目录下）');
    process.exit(1);
  }

  const SQL = await initSqlJs();
  const db = new SQL.Database();

  db.run(`
    CREATE TABLE IF NOT EXISTS memories (
      id         TEXT PRIMARY KEY,
      content    TEXT NOT NULL,
      embedding  BLOB,
      key        TEXT DEFAULT '',
      importance REAL DEFAULT 0.7,
      metadata   TEXT DEFAULT '{}',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  db.run(`
    CREATE INDEX IF NOT EXISTS idx_memories_key ON memories(key)
  `);

  db.run(`
    CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(created_at)
  `);

  // 落盘
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
  db.close();

  console.log(`✓ 创建 vectors.db（sql.js SQLite 向量数据库）`);
}

// ── 目录和文件初始化 ────────────────────────────────────────────────────────
function initDirectories() {
  if (!fs.existsSync(MEMORY_DIR)) {
    fs.mkdirSync(MEMORY_DIR, { recursive: true });
    console.log(`✓ 创建目录 ~/.openclaw/memory/`);
  } else {
    console.log(`• ~/.openclaw/memory/ 已存在`);
  }

  if (!fs.existsSync(DAILY_DIR)) {
    fs.mkdirSync(DAILY_DIR, { recursive: true });
    console.log(`✓ 创建目录 ~/.openclaw/memory/daily/`);
  } else {
    console.log(`• daily/ 目录已存在`);
  }
}

function initSessionState() {
  if (!fs.existsSync(SESSION_PATH)) {
    fs.writeFileSync(SESSION_PATH, SESSION_STATE_TEMPLATE());
    console.log(`✓ 创建 SESSION-STATE.md（热缓存）`);
  } else {
    console.log(`• SESSION-STATE.md 已存在`);
  }
}

function initMemoryMd() {
  if (!fs.existsSync(MEMORY_MD_PATH)) {
    fs.writeFileSync(MEMORY_MD_PATH, MEMORY_MD_TEMPLATE());
    console.log(`✓ 创建 MEMORY.md（长期记忆）`);
  } else {
    console.log(`• MEMORY.md 已存在`);
  }
}

function initTodayLog() {
  const today = new Date().toISOString().split('T')[0];
  const todayPath = path.join(DAILY_DIR, `${today}.md`);

  if (!fs.existsSync(todayPath)) {
    fs.writeFileSync(todayPath, DAILY_TEMPLATE(today));
    console.log(`✓ 创建今日日志 daily/${today}.md`);
  } else {
    console.log(`• daily/${today}.md 已存在`);
  }
  return todayPath;
}

// ── 主流程 ──────────────────────────────────────────────────────────────────
async function main() {
  const args = process.argv.slice(2);
  const todayOnly = args.includes('--today-only');
  const force = args.includes('--force');

  if (todayOnly) {
    if (!fs.existsSync(DAILY_DIR)) {
      fs.mkdirSync(DAILY_DIR, { recursive: true });
    }
    initTodayLog();
    return;
  }

  console.log('🧠 初始化 catclaw-memory 记忆系统...\n');

  initDirectories();
  await initDatabase(force);
  initSessionState();
  initMemoryMd();
  initTodayLog();

  console.log('\n🎉 记忆系统初始化完成！');
  console.log('\n下一步：');
  console.log('  1. 设置 AppId: export FRIDAY_APP_ID="你的Friday AppId"');
  console.log('  2. 存储第一条记忆: node vm-remember.js "你好，我是用户" --key meta/intro');
  console.log('  3. 搜索记忆: node vm-recall.js "用户信息"');
}

main().catch(err => {
  console.error('✗ 初始化失败:', err.message);
  process.exit(1);
});
