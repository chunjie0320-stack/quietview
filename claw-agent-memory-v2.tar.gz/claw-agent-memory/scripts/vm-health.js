#!/usr/bin/env node

/**
 * vm-health.js — 记忆库健康度检查工具
 *
 * 用法:
 *   node vm-health.js --status     # 统计各category记忆数量
 *   node vm-health.js --duplicates # 找出相似度>0.95的重复记忆
 *   node vm-health.js --stale      # 列出180天以上未更新的记忆
 *   node vm-health.js --report     # 完整报告（以上三项汇总）
 */

'use strict';

const fs   = require('fs');
const path = require('path');

// ── 路径配置 ─────────────────────────────────────────────────────────
const MEMORY_DIR = path.join(process.env.HOME, '.openclaw', 'memory');

function getDbPath(agentId) {
  if (agentId) return path.join(MEMORY_DIR, agentId, 'vectors.db');
  return path.join(MEMORY_DIR, 'vectors.db');
}

// ── 参数解析 ─────────────────────────────────────────────────────────
function parseArgs(argv) {
  const args = argv.slice(2);
  const result = {
    status: false,
    duplicates: false,
    stale: false,
    report: false,
    agent: null,
    threshold: 0.95,
    staleDays: 180,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    if (arg === '--status')          { result.status = true; i++; }
    else if (arg === '--duplicates') { result.duplicates = true; i++; }
    else if (arg === '--stale')      { result.stale = true; i++; }
    else if (arg === '--report')     { result.report = true; i++; }
    else if (arg === '--agent')      { result.agent = args[i + 1]; i += 2; }
    else if (arg === '--threshold')  { result.threshold = parseFloat(args[i + 1]); i += 2; }
    else if (arg === '--stale-days') { result.staleDays = parseInt(args[i + 1], 10); i += 2; }
    else i++;
  }
  return result;
}

// ── 向量反序列化 ──────────────────────────────────────────────────────
function blobToVector(blob) {
  const buf = Buffer.isBuffer(blob) ? blob : Buffer.from(blob);
  return new Float32Array(buf.buffer, buf.byteOffset, buf.byteLength / 4);
}

// ── 余弦相似度 ────────────────────────────────────────────────────────
function cosineSimilarity(a, b) {
  if (a.length !== b.length) return 0;
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot   += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

// ── 加载数据库 ────────────────────────────────────────────────────────
async function loadDb(initSqlJs, agentId) {
  const dbPath = getDbPath(agentId);
  if (!fs.existsSync(dbPath)) return null;
  const SQL      = await initSqlJs();
  const fileData = fs.readFileSync(dbPath);
  return new SQL.Database(fileData);
}

// ── KEY 分类前缀 ──────────────────────────────────────────────────────
const KEY_PREFIXES = ['preference', 'decision', 'lesson', 'constraint', 'milestone', 'context'];

function classifyKey(key) {
  if (!key) return 'uncategorized';
  for (const prefix of KEY_PREFIXES) {
    if (key.startsWith(prefix)) return prefix;
  }
  return 'other';
}

// ── --status：按key前缀统计 ───────────────────────────────────────────
async function cmdStatus(initSqlJs, agentId) {
  console.log('📊 记忆库状态统计\n');

  const dbPath = getDbPath(agentId);
  const label  = agentId ? ('[agent:' + agentId + ']') : '[全局]';

  if (!fs.existsSync(dbPath)) {
    console.log('✗ vectors.db ' + label + ' 未找到 (' + dbPath + ')');
    return null;
  }

  const db      = await loadDb(initSqlJs, agentId);
  const results = db.exec('SELECT key, importance, created_at FROM memories ORDER BY key');
  db.close();

  if (!results.length || !results[0].values.length) {
    console.log('💭 ' + label + ' 记忆库为空');
    return { total: 0, byCategory: {}, avgImportance: 0 };
  }

  const rows = results[0].values;
  const total = rows.length;

  const byCategory = {};
  let totalImportance = 0;
  rows.forEach(([key, importance]) => {
    const cat = classifyKey(key);
    if (!byCategory[cat]) byCategory[cat] = { count: 0, keys: new Set() };
    byCategory[cat].count++;
    byCategory[cat].keys.add(key || '(无标签)');
    totalImportance += (importance || 0.7);
  });

  const avgImportance = (totalImportance / total).toFixed(3);
  const sizeKB = (fs.statSync(dbPath).size / 1024).toFixed(1);

  console.log('🗄️  数据库 ' + label + ': ' + total + ' 条记忆 (' + sizeKB + 'KB，平均重要性: ' + avgImportance + ')\n');
  console.log('── 分类分布 ────────────────────────────────');

  const sorted = Object.entries(byCategory).sort((a, b) => b[1].count - a[1].count);
  for (const [cat, info] of sorted) {
    const bar = '█'.repeat(Math.round(info.count / total * 20));
    const pct = (info.count / total * 100).toFixed(1);
    console.log('  ' + cat.padEnd(15) + ' ' + String(info.count).padStart(4) + ' 条 (' + pct.padStart(5) + '%)  ' + bar);
    const keyList = [...info.keys].slice(0, 5).join(', ');
    const more = info.keys.size > 5 ? (' ...+' + (info.keys.size - 5)) : '';
    console.log('                   └ keys: ' + keyList + more);
  }

  console.log('');
  return { total, byCategory, avgImportance };
}

// ── --duplicates：找出高相似度重复记忆 ───────────────────────────────
async function cmdDuplicates(initSqlJs, agentId, threshold) {
  console.log('🔍 检查重复记忆（相似度 > ' + threshold + '）\n');

  const db = await loadDb(initSqlJs, agentId);
  if (!db) {
    console.log('✗ 数据库未找到');
    return [];
  }
  const label = agentId ? ('[agent:' + agentId + ']') : '[全局]';

  const results = db.exec('SELECT id, content, key, importance, embedding FROM memories');
  db.close();

  if (!results.length || !results[0].values.length) {
    console.log('💭 ' + label + ' 记忆库为空');
    return [];
  }

  const rows = results[0].values;
  const n = rows.length;

  if (n < 2) {
    console.log('✓ ' + label + ' 记忆数量 < 2，无需检查重复');
    return [];
  }

  console.log('  扫描 ' + n + ' 条记忆，进行两两比较（' + Math.round(n*(n-1)/2) + ' 对）...');

  const entries = rows.map(([id, content, key, importance, embBlob]) => ({
    id, content, key, importance,
    vec: embBlob ? blobToVector(embBlob) : null,
  })).filter(e => e.vec !== null);

  const duplicates = [];

  for (let i = 0; i < entries.length; i++) {
    for (let j = i + 1; j < entries.length; j++) {
      const sim = cosineSimilarity(entries[i].vec, entries[j].vec);
      if (sim >= threshold) {
        duplicates.push({ a: entries[i], b: entries[j], similarity: sim });
      }
    }
  }

  if (duplicates.length === 0) {
    console.log('✓ ' + label + ' 未找到相似度 > ' + threshold + ' 的重复记忆 🎉');
    return [];
  }

  duplicates.sort((x, y) => y.similarity - x.similarity);

  console.log('\n⚠️  ' + label + ' 发现 ' + duplicates.length + ' 对潜在重复记忆：\n');
  duplicates.forEach((d, idx) => {
    const simPct = (d.similarity * 100).toFixed(2);
    console.log((idx + 1) + '. 相似度: ' + simPct + '%');
    console.log('   A [' + (d.a.key || '无标签') + '] ' + d.a.id);
    console.log('     "' + d.a.content.substring(0, 80) + (d.a.content.length > 80 ? '...' : '') + '"');
    console.log('   B [' + (d.b.key || '无标签') + '] ' + d.b.id);
    console.log('     "' + d.b.content.substring(0, 80) + (d.b.content.length > 80 ? '...' : '') + '"');
    console.log('   💡 建议: node vm-hygiene.js --delete ' + d.b.id);
    console.log('');
  });

  return duplicates;
}

// ── --stale：列出长期未更新的记忆 ────────────────────────────────────
async function cmdStale(initSqlJs, agentId, staleDays) {
  console.log('🕰️  检查陈旧记忆（' + staleDays + ' 天以上）\n');

  const db = await loadDb(initSqlJs, agentId);
  if (!db) {
    console.log('✗ 数据库未找到');
    return [];
  }
  const label = agentId ? ('[agent:' + agentId + ']') : '[全局]';

  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - staleDays);
  const cutoffStr = cutoff.toISOString();

  const results = db.exec(
    'SELECT id, content, key, importance, created_at FROM memories WHERE created_at < ? ORDER BY created_at ASC',
    [cutoffStr]
  );
  db.close();

  if (!results.length || !results[0].values.length) {
    console.log('✓ ' + label + ' 没有 ' + staleDays + ' 天以上的陈旧记忆 🎉');
    return [];
  }

  const rows = results[0].values;
  console.log('⚠️  ' + label + ' 发现 ' + rows.length + ' 条陈旧记忆：\n');

  rows.forEach(([id, content, key, importance, createdAt], idx) => {
    const date = createdAt ? createdAt.split('T')[0] : '未知';
    const ageDays = createdAt
      ? Math.round((Date.now() - new Date(createdAt).getTime()) / (1000 * 60 * 60 * 24))
      : '?';
    console.log(String(idx + 1).padStart(3) + '. [' + (key || '无标签') + '] 重要性:' + importance + ' | 创建于 ' + date + '（' + ageDays + '天前）');
    console.log('     "' + content.substring(0, 80) + (content.length > 80 ? '...' : '') + '"');
    console.log('     id: ' + id);
  });

  console.log('\n💡 清理建议: node vm-hygiene.js --prune ' + staleDays);
  return rows;
}

// ── --report：完整报告 ────────────────────────────────────────────────
async function cmdReport(initSqlJs, agentId, threshold, staleDays) {
  const divider = '═'.repeat(56);
  console.log('\n' + divider);
  console.log('  🧠 记忆库健康度完整报告');
  console.log('  生成时间: ' + new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }));
  console.log(divider);

  console.log('\n【1/3】');
  const statusResult = await cmdStatus(initSqlJs, agentId);

  console.log('\n【2/3】');
  const dupeResult = await cmdDuplicates(initSqlJs, agentId, threshold);

  console.log('\n【3/3】');
  const staleResult = await cmdStale(initSqlJs, agentId, staleDays);

  console.log('\n' + divider);
  console.log('  📋 健康评分汇总');
  console.log(divider);

  if (statusResult) {
    const total = statusResult.total;
    const dupeCount = dupeResult.length;
    const staleCount = staleResult.length;

    let score = 100;
    if (total > 0) {
      score -= Math.min(30, Math.round(dupeCount / total * 100));
      score -= Math.min(20, Math.round(staleCount / total * 50));
    }

    const rating = score >= 90 ? '🟢 优秀' : score >= 70 ? '🟡 良好' : score >= 50 ? '🟠 需维护' : '🔴 需清理';
    console.log('\n  总记忆数:   ' + total + ' 条');
    console.log('  重复对数:   ' + dupeCount + ' 对');
    console.log('  陈旧记忆:   ' + staleCount + ' 条');
    console.log('  健康评分:   ' + score + '/100  ' + rating);

    if (dupeCount > 0 || staleCount > 0) {
      console.log('\n  💡 建议操作:');
      if (dupeCount > 0)  console.log('     node vm-hygiene.js --list     # 查看后手动删除重复');
      if (staleCount > 0) console.log('     node vm-hygiene.js --prune ' + staleDays + '  # 清理陈旧低重要性记忆');
    } else {
      console.log('\n  ✅ 记忆库状态良好，无需维护！');
    }
  } else {
    console.log('\n  ✗ 数据库未找到，请先运行: node vm-init.js');
  }

  console.log('\n' + divider + '\n');
}

// ── 主流程 ────────────────────────────────────────────────────────────
async function main() {
  const opts = parseArgs(process.argv);

  if (!opts.status && !opts.duplicates && !opts.stale && !opts.report) {
    console.log(`
🧠 vm-health — 记忆库健康度检查工具

用法:
  node vm-health.js --status           统计各category记忆数量
  node vm-health.js --duplicates       找出相似度 > 0.95 的重复记忆
  node vm-health.js --stale            列出 180 天以上未更新的记忆
  node vm-health.js --report           完整报告（以上三项汇总）

可选参数:
  --agent <id>           指定 agent 专属库（默认全局库）
  --threshold <0-1>      重复检测相似度阈值（默认 0.95）
  --stale-days <N>       陈旧记忆天数阈值（默认 180）
`);
    return;
  }

  let initSqlJs;
  try {
    initSqlJs = require('sql.js');
  } catch (e) {
    console.error('✗ 未找到 sql.js，请在技能目录运行: npm install');
    process.exit(1);
  }

  if (opts.report) {
    await cmdReport(initSqlJs, opts.agent, opts.threshold, opts.staleDays);
  } else {
    if (opts.status)     await cmdStatus(initSqlJs, opts.agent);
    if (opts.duplicates) await cmdDuplicates(initSqlJs, opts.agent, opts.threshold);
    if (opts.stale)      await cmdStale(initSqlJs, opts.agent, opts.staleDays);
  }
}

main().catch(err => {
  console.error('✗ 执行失败:', err.message);
  process.exit(1);
});
